/* Pure ARM32 AAPCS module; all OS services come from the SDK API table.
   Entry in r0 = XdosHostApiV1*. No absolute relocation, no libc, no Linux. */
.syntax unified
.arm
.section .xapp_header,"a",%progbits
.balign 4
.global xapp_image_start
xapp_image_start:
    .ascii "XDAP"
    .word 1                 @ ABI version
    .word 32                @ header bytes
    .word xapp_image_end-xapp_image_start
    .word xapp_entry-xapp_image_start
    .word 0                 @ flags
    .word 0                 @ checksum reserved
    .word 0                 @ reserved

.section .text,"ax",%progbits
.balign 4
.global xapp_entry
.type xapp_entry,%function
xapp_entry:
    push {r4,lr}
    cmp r0,#0
    beq invalid
    ldr r1,[r0,#0]         @ api->abi_version
    cmp r1,#1
    bne invalid
    ldr r1,[r0,#4]         @ api->struct_bytes
    cmp r1,#20
    blo invalid
    mov r4,r0
    ldr r0,[r4,#8]         @ api->context
    ldr r3,[r4,#16]        @ api->show_lvgl_demo
    cmp r3,#0
    beq invalid
    blx r3
    pop {r4,pc}
invalid:
    mvn r0,#0
    pop {r4,pc}
.balign 4
.global xapp_image_end
xapp_image_end:
