#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/circle"
cat > "$TMP/circle/font.h" <<'EOF'
#pragma once
static const int Font8x16=0;
EOF
cat > "$TMP/circle/chargenerator.h" <<'EOF'
#pragma once
class CCharGenerator {
public:
    typedef unsigned short TPixelLine;
    explicit CCharGenerator(int) {}
    TPixelLine GetPixelLine(char,unsigned) const {return 0;}
    bool GetPixel(unsigned,TPixelLine) const {return false;}
};
EOF
c++ -std=c++17 -Wall -Wextra -Werror -fsyntax-only -DXDOS_USE_LVGL=1 -I"$TMP" \
    "$ROOT/source/95-xdos-arm32-dualnet/desktop.cpp"
echo 'PASS: Desktop USB Terminal and storage command mock syntax'
