#ifndef CIRCLE_TIMER_STUB
#define CIRCLE_TIMER_STUB
class CTimer {public: static unsigned GetClockTicks(void);};
#endif
