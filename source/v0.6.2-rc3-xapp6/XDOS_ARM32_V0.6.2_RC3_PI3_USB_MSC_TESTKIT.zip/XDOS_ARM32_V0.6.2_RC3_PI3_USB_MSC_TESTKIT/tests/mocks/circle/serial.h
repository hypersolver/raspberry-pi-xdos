#ifndef CIRCLE_SERIAL_STUB
#define CIRCLE_SERIAL_STUB
#include <stddef.h>
class CSerialDevice {public:int Write(const void*,size_t);};
#endif
