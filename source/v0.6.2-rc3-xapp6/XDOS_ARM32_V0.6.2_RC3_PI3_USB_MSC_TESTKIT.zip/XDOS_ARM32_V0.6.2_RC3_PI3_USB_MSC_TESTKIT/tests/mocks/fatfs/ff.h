#ifndef FF_STUB
#define FF_STUB
#include <stdint.h>
#include <stddef.h>
typedef unsigned UINT;
typedef uint32_t FSIZE_t;
typedef struct FIL {unsigned n;} FIL;
typedef enum {FR_OK=0,FR_EXIST=8} FRESULT;
#define FA_WRITE 2
#define FA_OPEN_APPEND 0x30
FRESULT f_mkdir(const char*);FRESULT f_open(FIL*,const char*,unsigned);
FRESULT f_write(FIL*,const void*,UINT,UINT*);FRESULT f_sync(FIL*);
FRESULT f_close(FIL*); FSIZE_t f_size(FIL*);
#endif
