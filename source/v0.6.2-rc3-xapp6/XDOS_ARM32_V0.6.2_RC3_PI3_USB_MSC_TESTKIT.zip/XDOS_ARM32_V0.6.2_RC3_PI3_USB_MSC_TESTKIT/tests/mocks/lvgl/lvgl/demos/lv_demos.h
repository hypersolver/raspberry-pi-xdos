#ifndef LV_DEMOS_STUB
#define LV_DEMOS_STUB
void lv_demo_widgets(void);
#endif
