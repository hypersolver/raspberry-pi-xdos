#ifndef LVGL_STUB_H
#define LVGL_STUB_H
#include <stdint.h>
typedef struct lv_obj_t lv_obj_t;
typedef struct lv_display_t lv_display_t;
typedef struct lv_event_t lv_event_t;
typedef uint8_t lv_opa_t;
typedef int lv_event_code_t;
typedef void (*lv_event_cb_t)(lv_event_t*);
#define LV_EVENT_CLICKED 1
#define LV_EVENT_ALL 2
#define LV_EVENT_RENDER_START 3
#define LV_EVENT_RENDER_READY 4
#define LV_EVENT_FLUSH_START 5
#define LV_EVENT_FLUSH_FINISH 6
#define LV_ALIGN_TOP_RIGHT 1
#define LV_ALIGN_TOP_LEFT 2
#define LV_ALIGN_BOTTOM_LEFT 3
#define LV_ALIGN_TOP_MID 4
#define LV_FLEX_FLOW_COLUMN 1
#define LV_FLEX_FLOW_ROW 2
#define LV_SCROLLBAR_MODE_OFF 0
#define LV_LABEL_LONG_WRAP 1
#define LV_OPA_50 128
#define LV_OPA_COVER 255
#define LV_PCT(x) (x)
#define lv_pct(x) (x)
#define LV_SIZE_CONTENT 100
#define LV_OBJ_FLAG_SCROLLABLE 0
#ifdef __cplusplus
extern "C" {
#endif
lv_event_code_t lv_event_get_code(lv_event_t*);
void *lv_event_get_user_data(lv_event_t*);
lv_obj_t *lv_obj_create(lv_obj_t*); lv_obj_t *lv_label_create(lv_obj_t*);lv_obj_t*lv_button_create(lv_obj_t*);
lv_display_t *lv_display_get_default(void);
int lv_display_get_horizontal_resolution(lv_display_t*);int lv_display_get_vertical_resolution(lv_display_t*);
void lv_display_add_event_cb(lv_display_t*,lv_event_cb_t,lv_event_code_t,void*);
void lv_obj_add_event_cb(lv_obj_t*,lv_event_cb_t,lv_event_code_t,void*);
void lv_obj_set_size(lv_obj_t*,int,int);void lv_obj_set_height(lv_obj_t*,int);void lv_obj_set_width(lv_obj_t*,int);
void lv_obj_set_pos(lv_obj_t*,int,int);void lv_obj_align(lv_obj_t*,int,int,int);void lv_obj_center(lv_obj_t*);
void lv_obj_set_style_bg_color(lv_obj_t*,unsigned,int);void lv_obj_set_style_text_color(lv_obj_t*,unsigned,int);
void lv_obj_set_style_border_width(lv_obj_t*,int,int);void lv_obj_set_style_pad_all(lv_obj_t*,int,int);
void lv_obj_set_style_pad_row(lv_obj_t*,int,int);void lv_obj_set_style_radius(lv_obj_t*,int,int);
void lv_obj_set_style_bg_opa(lv_obj_t*,lv_opa_t,int);
void lv_obj_set_flex_flow(lv_obj_t*,int);void lv_obj_set_scrollbar_mode(lv_obj_t*,int);
void lv_label_set_text(lv_obj_t*,const char*);void lv_label_set_text_fmt(lv_obj_t*,const char*,...);
void lv_label_set_long_mode(lv_obj_t*,int);
void lv_obj_clean(lv_obj_t*);lv_obj_t*lv_obj_get_child(lv_obj_t*,int);
int lv_obj_get_width(lv_obj_t*);int lv_obj_get_height(lv_obj_t*);
void lv_obj_move_foreground(lv_obj_t*);void lv_obj_update_layout(lv_obj_t*);
void lv_obj_delete(lv_obj_t*);void lv_obj_delete_async(lv_obj_t*);
void lv_screen_load(lv_obj_t*);lv_obj_t*lv_screen_active(void);
unsigned lv_color_hex(unsigned);
#ifdef __cplusplus
}
#endif
#endif
