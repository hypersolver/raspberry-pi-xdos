#include "../source/95-xdos-arm32-dualnet/usb_storage_policy.h"
#include <cassert>
#include <cstring>
#include <iostream>
int main() {
    char b[64];
    assert(XdosUSBMakePath(b,sizeof(b),"TEST.TXT"));
    assert(std::strcmp(b,"USB:/TEST.TXT")==0);
    assert(!XdosUSBMakePath(b,sizeof(b),"../BAD.TXT"));
    assert(!XdosUSBMakePath(b,sizeof(b),"A/B"));
    assert(!XdosUSBMakePath(b,sizeof(b),"USB:DATA"));
    assert(!XdosUSBMakePath(b,sizeof(b),".hidden"));
    assert(!XdosUSBMakePath(b,sizeof(b),"A\\B"));
    assert(!XdosUSBMakePath(b,8,"TEST.TXT"));
    assert(!XdosUSBFileNameValid(""));
    assert(!XdosUSBFileNameValid(".."));
    assert(XdosUSBFileNameValid("LOG_2026.TXT"));
    std::cout << "USB filename and path guard: PASS\\n";
}
