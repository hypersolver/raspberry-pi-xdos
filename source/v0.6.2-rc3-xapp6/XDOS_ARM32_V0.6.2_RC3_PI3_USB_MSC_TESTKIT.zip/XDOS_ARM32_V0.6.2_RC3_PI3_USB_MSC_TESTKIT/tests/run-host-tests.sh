#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
g++ -std=c++17 -O2 -Wall -Wextra -Werror -o /tmp/xdos-v062-bench-flush-test "$root/tests/test_lvgl_flush.cpp"
/tmp/xdos-v062-bench-flush-test

python3 "$root/tests/test_circle_p0_patch.py"

# USB root-only path validation; this host test does not emulate USB/FatFs.
g++ -std=c++17 -O2 -Wall -Wextra -Werror -o /tmp/xdos-v062-usb-policy-test "$root/tests/test_usb_storage_policy.cpp"
/tmp/xdos-v062-usb-policy-test

# USB storage C++ interface checks (Circle mocks, not real hardware).
bash "$root/tests/run-usb-mock-syntax-check.sh"
bash "$root/tests/run-desktop-mock-syntax-check.sh"
