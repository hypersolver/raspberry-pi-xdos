#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/circle/sched" "$TMP/circle" "$TMP/fatfs"
cat > "$TMP/circle/device.h" <<'EOF'
#pragma once
class CDevice {};
EOF
cat > "$TMP/circle/sched/task.h" <<'EOF'
#pragma once
class CTask { public: CTask(unsigned) {} virtual ~CTask()=default; virtual void Run()=0; void SetName(const char *) {} };
EOF
cat > "$TMP/circle/sched/scheduler.h" <<'EOF'
#pragma once
class CScheduler { public: static CScheduler *Get(); void MsSleep(unsigned); };
EOF
cat > "$TMP/circle/timer.h" <<'EOF'
#pragma once
class CTimer { public: static unsigned GetClockTicks(); };
EOF
cat > "$TMP/circle/devicenameservice.h" <<'EOF'
#pragma once
#include "circle/device.h"
class CDeviceNameService { public: static CDeviceNameService *Get(); CDevice *GetDevice(const char *,bool); };
EOF
cat > "$TMP/circle/string.h" <<'EOF'
#pragma once
class CString { public: template <typename... T> void Format(const char *,T...); operator const char*() const; };
EOF
cat > "$TMP/fatfs/ff.h" <<'EOF'
#pragma once
#include <stddef.h>
#define FA_READ 1
#define FA_WRITE 2
#define FA_CREATE_ALWAYS 8
#define AM_DIR 16
typedef unsigned UINT;
enum FRESULT {FR_OK=0,FR_DISK_ERR,FR_NOT_READY,FR_NO_FILE,FR_NO_PATH,FR_INVALID_NAME,FR_INVALID_OBJECT,FR_INVALID_PARAMETER,FR_NO_FILESYSTEM,FR_EXIST};
struct FIL { size_t bytes; };
struct DIR { int x; };
struct FATFS { int x; };
struct FILINFO { char fname[256]; unsigned fattrib; unsigned long fsize; };
inline size_t f_size(FIL *f) {return f->bytes;}
FRESULT f_mount(FATFS *,const char *,int);
FRESULT f_opendir(DIR *,const char *);
FRESULT f_readdir(DIR *,FILINFO *);
FRESULT f_closedir(DIR *);
FRESULT f_open(FIL *,const char *,unsigned);
FRESULT f_close(FIL *);
FRESULT f_read(FIL *,void *,UINT,UINT *);
FRESULT f_write(FIL *,const void *,UINT,UINT *);
FRESULT f_sync(FIL *);
FRESULT f_mkdir(const char *);
FRESULT f_unlink(const char *);
FRESULT f_rename(const char *,const char *);
EOF
c++ -std=c++17 -Wall -Wextra -Werror -fsyntax-only -I"$TMP" \
    "$ROOT/source/95-xdos-arm32-dualnet/storage.cpp"
echo 'PASS: USB Mass Storage / FatFs worker mock syntax'
