#include <assert.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "../source/95-xdos-arm32-dualnet/lvgl_flush_fast.h"

static void test16()
{
    uint8_t frame[5*16]; memset(frame,0xCC,sizeof frame);
    uint16_t source[]={0xf800,0x07e0,0x001f,0xffff};
    assert(xdos_flush_rgb565(frame,16,16,4,5,1,1,2,2,source)==4);
    uint16_t expected[]={0xf800,0x07e0,0x001f,0xffff};
    for (int y=0;y<2;y++)for(int x=0;x<2;x++){
        uint16_t val=0;
        memcpy(&val, frame+(y+1)*16+(x+1)*2,2);
        assert(val==expected[y*2+x]);
    }
    assert(frame[0]==0xCC); // untouched margin
}
static void test32()
{
    uint8_t frame[3*24];memset(frame,0xAA,sizeof frame);
    uint16_t source[]={0xf800,0x07e0,0x001f,0xffff};
    assert(xdos_flush_rgb565(frame,24,32,4,3,0,0,1,1,source)==4);
    const uint32_t expected[]={0xffff0000,0xff00ff00,0xff0000ff,0xffffffff};
    for(int y=0;y<2;y++)for(int x=0;x<2;x++){
        uint32_t val=0;memcpy(&val,frame+y*24+x*4,4);
        assert(val==expected[y*2+x]);
    }
    assert(frame[23]==0xAA);
}
static void testClipped()
{
    uint8_t frame[2*8];memset(frame,0,sizeof frame);
    uint16_t src[]={0,1,2,3,4,5,6,7,8};
    // 3x3 source from -1,-1; only a 2x2 bottom-right square is visible.
    assert(xdos_flush_rgb565(frame,8,16,4,2,-1,-1,1,1,src)==4);
    uint16_t a=0,b=0,c=0,d=0;
    memcpy(&a,frame,2); memcpy(&b,frame+2,2);
    memcpy(&c,frame+8,2); memcpy(&d,frame+10,2);
    assert(a==4 && b==5 && c==7 && d==8);
    assert(xdos_flush_rgb565(frame,8,16,4,2,20,20,21,21,src)==0);
}
int main(){test16();test32();testClipped();puts("PASS: RGB565 flush 16/32-bit, pitch and clipping");}
