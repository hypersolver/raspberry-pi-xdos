#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
D="$ROOT/source/95-xdos-arm32-dualnet"
for f in xdos_lvgl.cpp xdos_benchmark.cpp; do
  g++ -std=c++17 -Wall -Wextra -Werror -fsyntax-only -I"$ROOT/tests/mocks" "$D/$f"
done
echo 'PASS: LVGL Benchmark/GUI host mock syntax'
