from pathlib import Path
import subprocess,tempfile,os
source=Path(__file__).resolve().parents[1]/'tools/patch-circle-gfx-p0.py'
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp); lv=root/'addon/lvgl/lvgl.cpp'; fb=root/'lib/bcmframebuffer.cpp'
    lv.parent.mkdir(parents=True);fb.parent.mkdir(parents=True)
    lv.write_text('''#include <lvgl/lvgl.h>
void CLVGL::Initialize () {
unsigned nBufSizePixels = nWidth * nHeight/10;
lv_display_set_buffers (display, m_pBuffer1, m_pBuffer2, nBufSizePixels * sizeof (u16),
\tLV_DISP_RENDER_MODE_PARTIAL);
}
void CLVGL::Update () {
if (nTicks - m_nLastUpdate >= 5*CLOCKHZ/1000)
{
lv_timer_handler ();
}
}
void CLVGL::DisplayFlush () {
s_pThis->m_pDisplay->SetArea (Area, pBuffer, DisplayFlushComplete, pDisplay);
}
void CLVGL::DisplayFlushComplete (void *pParam)
{
\tlv_display_t *pDisplay = (lv_display_t *) pParam;
lv_display_flush_ready(pDisplay);
}
''')
    fb.write_text('''#include <circle/atomic.h>
void CBcmFrameBuffer::SetArea () {
#ifdef SCREEN_DMA_BURST_LENGTH
\twhile (AtomicCompareExchange (&m_nDMAInUse, 0, 1))
\t{
\t\t// TODO: Yield with NO_BUSY_WAIT, when on core 0 in TASK_LEVEL
\t}
#endif
}
''')
    subprocess.run(['python3',str(source),str(root)],check=True)
    a=lv.read_text();b=fb.read_text()
    assert 'XDOS_P0_ASYNC_DMA_V2' in a and 'xdos_p0_dma_completed' in a
    assert 'CScheduler::Get ()->MsSleep (1)' in b
    env=dict(os.environ,XDOS_BUFFER_ROWS='96',XDOS_DMA_MIN_PIXELS='1024')
    subprocess.run(['python3',str(source),str(root)],env=env,check=True)
    assert '#define XDOS_P0_BUFFER_ROWS 96' in lv.read_text()
    assert '#define XDOS_P0_MIN_DMA_PIXELS 1024' in lv.read_text()
    subprocess.run(['python3',str(source),str(root)],env=env,check=True)
    print('PASS P0 patch: pristine, reconfigure, rerun idempotence')
