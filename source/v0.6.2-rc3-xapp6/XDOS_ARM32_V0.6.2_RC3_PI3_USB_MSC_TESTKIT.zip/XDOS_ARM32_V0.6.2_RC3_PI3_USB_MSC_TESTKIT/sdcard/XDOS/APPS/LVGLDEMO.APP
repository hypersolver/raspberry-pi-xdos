[Application]
Name=LVGL DEMO
Exec=SD:/XDOS/APPS/LVGLDEMO.XAPP
Icon=LVGL
ABI=1
Arch=armv7-a32
