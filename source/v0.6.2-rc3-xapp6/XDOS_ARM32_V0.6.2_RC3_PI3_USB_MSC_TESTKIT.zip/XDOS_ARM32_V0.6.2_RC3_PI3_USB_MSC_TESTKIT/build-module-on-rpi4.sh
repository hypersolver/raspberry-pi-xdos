#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$ROOT/output"
for app in lvgl_demo lvgl_bench; do
  arm-none-eabi-gcc -mcpu=cortex-a53 -marm -ffreestanding -c "$ROOT/${app}.S" -o "$ROOT/output/${app}.o"
  arm-none-eabi-ld -T "$ROOT/module.ld" -nostdlib -o "$ROOT/output/${app}.elf" "$ROOT/output/${app}.o"
  name=LVGLDEMO
  [[ "$app" == lvgl_bench ]] && name=LVGLBENCH
  arm-none-eabi-objcopy -O binary "$ROOT/output/${app}.elf" "$ROOT/output/${name}.XAPP"
  python3 "$ROOT/check_xapp.py" "$ROOT/output/${name}.XAPP"
  cp "$ROOT/sdcard/XDOS/APPS/${name}.APP" "$ROOT/output/${name}.APP"
done
