#ifndef XDOS_LVGL_FLUSH_FAST_H
#define XDOS_LVGL_FLUSH_FAST_H

// Bare-metal, allocation-free RGB565 -> display flush.
// This helper has no Circle/LVGL dependency so it can be unit tested on host.
#include <stdint.h>
#include <string.h>

static inline uint32_t xdos_rgb565_xrgb8888(uint16_t p)
{
    const uint32_t r5 = (p >> 11) & 31u;
    const uint32_t g6 = (p >> 5) & 63u;
    const uint32_t b5 = p & 31u;
    return 0xFF000000u | (((r5 << 3) | (r5 >> 2)) << 16)
                       | (((g6 << 2) | (g6 >> 4)) << 8)
                       | ((b5 << 3) | (b5 >> 2));
}

static inline unsigned xdos_flush_rgb565(void *front, unsigned pitch,
                                           unsigned depth, unsigned width,
                                           unsigned height,
                                           int x1, int y1, int x2, int y2,
                                           const uint16_t *pixels)
{
    if (!front || !pixels || (depth != 16 && depth != 32) ||
        width == 0 || height == 0 || x2 < x1 || y2 < y1) return 0;
    if ((uint64_t)pitch < (uint64_t)width * (depth/8u)) return 0;
    const int64_t sourceWidth = (int64_t)x2 - x1 + 1;
    if (sourceWidth <= 0 || sourceWidth > 32768) return 0;
    const int sx = x1 < 0 ? 0 : x1;
    const int sy = y1 < 0 ? 0 : y1;
    const int ex = x2 >= (int)width ? (int)width - 1 : x2;
    const int ey = y2 >= (int)height ? (int)height - 1 : y2;
    if (sx > ex || sy > ey) return 0;
    const unsigned cols = (unsigned)(ex - sx + 1);
    uint8_t *display = (uint8_t *)front;
    for (int y = sy; y <= ey; ++y) {
        const uint16_t *source = pixels + (unsigned)(y-y1)*sourceWidth + (unsigned)(sx-x1);
        uint8_t *target = display + (unsigned)y*pitch + (unsigned)sx*(depth/8u);
        if (depth == 16) {
            // Fast path: 1 contiguous copy per row, with actual destination pitch.
            memcpy(target, source, cols*sizeof(uint16_t));
        } else {
            // 32-bit XRGB8888; avoid per-pixel division and temporary buffers.
            for (unsigned x = 0; x < cols; ++x) {
                uint32_t color = xdos_rgb565_xrgb8888(source[x]);
                memcpy(target + x*4u, &color, 4);
            }
        }
    }
    return cols * (unsigned)(ey-sy+1);
}
#endif
