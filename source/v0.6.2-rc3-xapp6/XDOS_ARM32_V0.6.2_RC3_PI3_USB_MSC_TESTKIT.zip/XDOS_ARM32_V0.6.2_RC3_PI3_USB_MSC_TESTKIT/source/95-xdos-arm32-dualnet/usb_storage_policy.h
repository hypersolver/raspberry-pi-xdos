#ifndef XDOS_USB_STORAGE_POLICY_H
#define XDOS_USB_STORAGE_POLICY_H
#include <string.h>

// A USB FAT volume accepts root-level filenames only from Terminal.
// No path separators, drive selectors, control characters or traversal.
// Operations are deliberately bounded to avoid arbitrary-path writes.
static inline bool XdosUSBFileNameValid(const char *name)
{
    if(!name || !*name || name[0]=='.') return false;
    const unsigned n=(unsigned)strlen(name);
    if(n>48 || strstr(name,"..")) return false;
    for(unsigned i=0;i<n;i++) {
        const char c=name[i];
        if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||
             (c>='0'&&c<='9')||c=='.'||c=='_'||c=='-')) return false;
    }
    return true;
}
static inline bool XdosUSBMakePath(char *dest,unsigned cap,const char *name)
{
    if(!dest || !XdosUSBFileNameValid(name)) return false;
    const unsigned n=(unsigned)strlen(name);
    if(n+6>cap) return false; // "USB:/" (5) + NUL (1)
    memcpy(dest,"USB:/",5);
    memcpy(dest+5,name,n+1);
    return true;
}
#endif
