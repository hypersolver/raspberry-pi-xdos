#include "xapp_loader.h"
#include <fatfs/ff.h>
#include <circle/synchronize.h>
#include <stdint.h>
#include <string.h>

/* Pi 3: Circle page table maps normal heap with Execute-Never (XN).
 * Load/validate through heap, then copy into an EXECUTABLE .text slot.
 * Slot is defined by xapp_exec_slot.S and guaranteed to precede _etext
 * by tools/check-exec-section.py after full Circle link.
 * V1 supports only ONE trusted native XAPP at a time. */
extern "C" unsigned char xdos_xapp_exec_slot[];
extern "C" unsigned char xdos_xapp_exec_slot_end[];

static void Trace(const XdosHostApiV1 *api, const char *s)
{
    if (api && api->log) api->log(api->context, s);
}

XappLoaderV1::Result XappLoaderV1::ExecuteFile(const char *path, const XdosHostApiV1 *api)
{
    if (!path || !api || api->abi_version != XDOS_ABI_VERSION ||
        api->struct_bytes < sizeof(XdosHostApiV1)) return FORMAT_INVALID;

    FIL file;
    FRESULT fr = f_open(&file, path, FA_READ);
    if (fr != FR_OK) return OPEN_FAILED;
    const FSIZE_t fileSize = f_size(&file);
    if (fileSize < sizeof(XdosXappHeaderV1) || fileSize > XDOS_XAPP_MAX_SIZE) {
        f_close(&file);
        return SIZE_INVALID;
    }
    const uintptr_t slotSize = (uintptr_t)xdos_xapp_exec_slot_end -
                               (uintptr_t)xdos_xapp_exec_slot;
    if (slotSize < (uintptr_t)fileSize || slotSize != XDOS_XAPP_MAX_SIZE ||
        ((uintptr_t)xdos_xapp_exec_slot & 63u)) {
        f_close(&file);
        return MEMORY_FAILED;
    }

    unsigned char *image = new unsigned char[(unsigned)fileSize];
    if (!image) { f_close(&file); return MEMORY_FAILED; }
    UINT got=0;
    fr=f_read(&file,image,(UINT)fileSize,&got);
    const FRESULT closeResult=f_close(&file);
    if (fr != FR_OK || closeResult != FR_OK || got != (UINT)fileSize) {
        delete [] image;
        return READ_FAILED;
    }

    const XdosXappHeaderV1 *h=(const XdosXappHeaderV1 *)image;
    if (h->magic[0]!='X' || h->magic[1]!='D' ||
        h->magic[2]!='A' || h->magic[3]!='P' ||
        h->abi_version != XDOS_ABI_VERSION ||
        h->header_bytes != sizeof(*h) ||
        h->image_bytes != (uint32_t)fileSize || h->flags ||
        h->checksum || h->reserved ||
        h->entry_offset < h->header_bytes ||
        h->entry_offset >= h->image_bytes ||
        (h->entry_offset & 3u)) {
        delete [] image;
        return FORMAT_INVALID;
    }
    const uint32_t entryOffset=h->entry_offset;
    Trace(api,"[XAPP] Header / ABI validated\r\n");
    memcpy(xdos_xapp_exec_slot,image,(unsigned)fileSize);
    delete [] image;
    /* Make the copied instructions visible to instruction fetch.
     * This is NOT an XN workaround: .text itself is executable. */
    SyncDataAndInstructionCache();
    Trace(api,"[XAPP] Executable slot ready; entering ARM32 module\r\n");
    const uintptr_t entryAddress=(uintptr_t)xdos_xapp_exec_slot+entryOffset;
    XdosAppEntryV1 entry=reinterpret_cast<XdosAppEntryV1>(entryAddress);
    int32_t appResult=entry(api);
    Trace(api,"[XAPP] ARM32 module returned to XD OS\r\n");
    return appResult==0 ? OK : ENTRY_ERROR;
}
