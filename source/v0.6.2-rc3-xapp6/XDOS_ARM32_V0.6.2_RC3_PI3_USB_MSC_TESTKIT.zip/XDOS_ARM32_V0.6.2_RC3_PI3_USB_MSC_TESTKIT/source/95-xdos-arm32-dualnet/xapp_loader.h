#ifndef XDOS_XAPP_LOADER_H
#define XDOS_XAPP_LOADER_H
#include "xdos_sdk_v1.h"
/* Built against Circle's FatFs; call only from GUI TASK_LEVEL, never IRQ. */
class XappLoaderV1 {
public:
    enum Result {
        OK = 0, NOT_READY=-1, OPEN_FAILED=-2, SIZE_INVALID=-3,
        READ_FAILED=-4, FORMAT_INVALID=-5, MEMORY_FAILED=-6,
        ENTRY_ERROR=-7
    };
    static Result ExecuteFile(const char *path,const XdosHostApiV1 *api);
};
#endif
