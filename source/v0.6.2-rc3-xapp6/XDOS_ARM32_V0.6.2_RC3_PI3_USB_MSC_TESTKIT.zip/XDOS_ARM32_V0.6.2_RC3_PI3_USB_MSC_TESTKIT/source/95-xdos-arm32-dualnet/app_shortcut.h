#ifndef XDOS_APP_SHORTCUT_H
#define XDOS_APP_SHORTCUT_H
#include "xdos_sdk_v1.h"
// Call only from main Circle task after FAT32 mount. No hardware IRQ calls.
const char *XdosRunLVGLShortcut(const XdosHostApiV1 *api);
const char *XdosRunBenchmarkShortcut(const XdosHostApiV1 *api);
#endif
