/* XD OS trusted XAPP execution slot for Pi 3 AArch32.
 * Circle lib/pagetable.cpp maps only kernel text (_etext) as executable.
 * Normal heap is NORMAL_XN. Do NOT execute copied instructions from heap.
 * This slot is linked into .text and included in the RPi3 executable mapping.
 * Privileged developer-only module; no memory isolation or signature check. */
.syntax unified
.arm
.section .text.xdos_xapp_slot, "ax", %progbits
.balign 64
.global xdos_xapp_exec_slot
.type xdos_xapp_exec_slot, %object
xdos_xapp_exec_slot:
    .space 65536, 0
.global xdos_xapp_exec_slot_end
xdos_xapp_exec_slot_end:
.size xdos_xapp_exec_slot, xdos_xapp_exec_slot_end - xdos_xapp_exec_slot
