#ifndef XDOS_STORAGE_H
#define XDOS_STORAGE_H
#include <circle/sched/task.h>
#include <fatfs/ff.h>
#include <circle/device.h>
class Desktop;

// Serializes XD OS SD and USB application commands. USB mounting is probed
// only after the desktop is visible. Single supported USB volume: USB:.
class CStorageTask : public CTask
{
public:
    explicit CStorageTask(Desktop *desktop);
    void Run(void) override;
private:
    void PollUSB();
    FRESULT MountUSB();
    FRESULT EjectUSB();
    Desktop *desktop_;
    FATFS usbFS_;
    CDevice *lastUSBDevice_;
    bool usbMounted_,usbEjected_;
};
#endif
