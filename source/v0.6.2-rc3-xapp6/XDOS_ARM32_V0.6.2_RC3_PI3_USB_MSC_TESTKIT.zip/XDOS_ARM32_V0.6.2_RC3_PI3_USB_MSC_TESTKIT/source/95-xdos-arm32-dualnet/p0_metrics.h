#ifndef XDOS_P0_METRICS_H
#define XDOS_P0_METRICS_H
// Counters from Circle's single LVGL DMA driver. 32-bit and monotonic; read
// deltas within each 10s benchmark scene. Does not represent HDMI VSYNC.
#ifdef __cplusplus
extern "C" {
#endif
extern volatile unsigned xdos_p0_dma_submitted;
extern volatile unsigned xdos_p0_dma_completed;
extern volatile unsigned xdos_p0_dma_total_us;
extern volatile unsigned xdos_p0_dma_max_us;
extern volatile unsigned xdos_p0_dirty_pixels;
extern volatile unsigned xdos_p0_cpu_flushes;
#ifdef __cplusplus
}
#endif
#endif
