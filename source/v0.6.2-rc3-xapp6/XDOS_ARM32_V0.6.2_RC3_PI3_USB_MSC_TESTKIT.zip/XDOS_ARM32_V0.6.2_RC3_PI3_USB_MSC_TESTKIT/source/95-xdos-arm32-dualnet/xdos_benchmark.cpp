#include "xdos_benchmark.h"
#include "p0_metrics.h"
#include "desktop.h"
#include <circle/serial.h>
#include <circle/timer.h>
#include <fatfs/ff.h>
#include <stdio.h>
#include <string.h>
#ifndef XDOS_P0_BUFFER_ROWS_REPORT
#define XDOS_P0_BUFFER_ROWS_REPORT 64
#endif
#ifndef XDOS_P0_MIN_DMA_PIXELS_REPORT
#define XDOS_P0_MIN_DMA_PIXELS_REPORT 512
#endif

namespace {
static const unsigned WARMUP_US=2000000U, RUN_US=10000000U, FRAME_US=20000U;
static XDOSBenchmark *g_bench=0;
}
const char *XDOSBenchmark::Name(unsigned i) {
    static const char *names[]={"TEXT_24","MOVE_36","ALPHA_24","FULL_REDRAW"};
    return i<SCENES ? names[i] : "UNKNOWN";
}
XDOSBenchmark::XDOSBenchmark()
:home_(0),screen_(0),area_(0),info_(0),report_(0),desktop_(0),serial_(0),
 active_(false),complete_(false),registered_(false),scene_(0),step_(0),
 startUs_(0),measureUs_(0),lastUpdateUs_(0),lastInfoUs_(0),measuring_(false),
 renderStart_(0),flushStart_(0),renderCount_(0),flushCount_(0),renderMax_(0),flushMax_(0),
 renderTotal_(0),flushTotal_(0),
 dmaBaseCount_(0),dmaBaseTotal_(0),dirtyBase_(0),cpuBase_(0)
{memset(obj_,0,sizeof obj_);memset(samples_,0,sizeof samples_);result_[0]=0;}
void XDOSBenchmark::Log(const char *s) {if(serial_&&s)serial_->Write(s,strlen(s));}
void XDOSBenchmark::Reset() {
    renderStart_=flushStart_=renderCount_=flushCount_=renderMax_=flushMax_=0;
    renderTotal_=flushTotal_=0;
    dmaBaseCount_=xdos_p0_dma_completed;
    dmaBaseTotal_=xdos_p0_dma_total_us;
    dirtyBase_=xdos_p0_dirty_pixels;
    cpuBase_=xdos_p0_cpu_flushes;
}
void XDOSBenchmark::DisplayCallback(lv_event_t *event) {
    XDOSBenchmark *p=static_cast<XDOSBenchmark*>(lv_event_get_user_data(event));
    if(p)p->OnDisplay(event);
}
void XDOSBenchmark::OnDisplay(lv_event_t *event) {
    if(!active_||!measuring_)return;
    const unsigned t=CTimer::GetClockTicks();
    switch(lv_event_get_code(event)) {
    case LV_EVENT_RENDER_START: renderStart_=t?t:1; break;
    case LV_EVENT_RENDER_READY:
        if(renderStart_) {unsigned dt=t-renderStart_;renderStart_=0;
            renderTotal_+=dt;renderMax_=dt>renderMax_?dt:renderMax_;++renderCount_;}
        break;
    case LV_EVENT_FLUSH_START: flushStart_=t?t:1;break;
    case LV_EVENT_FLUSH_FINISH:
        if(flushStart_) {unsigned dt=t-flushStart_;flushStart_=0;
            flushTotal_+=dt;flushMax_=dt>flushMax_?dt:flushMax_;++flushCount_;}
        break;
    default:break;
    }
}
void XDOSBenchmark::BackCallback(lv_event_t *event) {
    if(lv_event_get_code(event)==LV_EVENT_CLICKED && g_bench)g_bench->Back();
}
void XDOSBenchmark::Back() {
    if(!active_)return;
    active_=false;measuring_=false;
    lv_screen_load(home_);
    if(screen_)lv_obj_delete_async(screen_); // safe from a button event callback
    screen_=area_=info_=report_=0;
    memset(obj_,0,sizeof obj_);
}
bool XDOSBenchmark::Start(lv_obj_t *home,Desktop *desktop,CSerialDevice *serial) {
    if(!home||active_)return false;
    home_=home;desktop_=desktop;serial_=serial;g_bench=this;
    lv_display_t *disp=lv_display_get_default();
    if(!disp)return false;
    if(!registered_) {
        lv_display_add_event_cb(disp,DisplayCallback,LV_EVENT_ALL,this);
        registered_=true;
    }
    screen_=lv_obj_create(NULL);
    lv_obj_set_style_pad_all(screen_,0,0);
    lv_obj_set_style_border_width(screen_,0,0);
    lv_obj_set_style_bg_color(screen_,lv_color_hex(0x0E1929),0);
    lv_obj_t *title=lv_label_create(screen_);
    lv_label_set_text(title,"XD OS / LVGL 9 / PERFORMANCE BENCHMARK");
    lv_obj_align(title,LV_ALIGN_TOP_LEFT,14,8);
    lv_obj_t *back=lv_button_create(screen_);
    lv_obj_set_size(back,125,36);
    lv_obj_align(back,LV_ALIGN_TOP_RIGHT,-12,5);
    lv_obj_add_event_cb(back,BackCallback,LV_EVENT_CLICKED,NULL);
    lv_obj_t *bLabel=lv_label_create(back);lv_label_set_text(bLabel,"BACK / STOP");lv_obj_center(bLabel);
    info_=lv_label_create(screen_);lv_obj_align(info_,LV_ALIGN_TOP_LEFT,14,52);
    area_=lv_obj_create(screen_);
    lv_obj_set_size(area_,lv_pct(98),lv_pct(78));
    lv_obj_align(area_,LV_ALIGN_TOP_MID,0,82);
    lv_obj_set_style_pad_all(area_,0,0);
    lv_obj_set_style_radius(area_,0,0);
    lv_obj_set_style_border_width(area_,0,0);
    lv_obj_set_scrollbar_mode(area_,LV_SCROLLBAR_MODE_OFF);
    report_=lv_label_create(screen_);
    lv_obj_align(report_,LV_ALIGN_BOTTOM_LEFT,14,-5);
    lv_label_set_text(report_,"2s warmup + 10s measured per scene; total ~48 seconds");
    lv_screen_load(screen_);
    lv_obj_update_layout(screen_);
    scene_=step_=0;complete_=false;measuring_=false;
    const unsigned now=CTimer::GetClockTicks();
    startUs_=measureUs_=lastUpdateUs_=lastInfoUs_=now;
    memset(samples_,0,sizeof samples_);Reset();MakeScene(scene_);
    active_=true;
    Log("[XDOS BENCH] START v0.6.2-RC2 / 4 scenes / P0 Hybrid Async DMA\r\n");
    return true;
}
void XDOSBenchmark::MakeScene(unsigned n) {
    lv_obj_clean(area_);memset(obj_,0,sizeof obj_);
    lv_obj_set_style_bg_color(area_,lv_color_hex(0x203349),0);
    const int w=lv_obj_get_width(area_)>100?lv_obj_get_width(area_):900;
    const int h=lv_obj_get_height(area_)>100?lv_obj_get_height(area_):500;
    if(n==3)return;
    unsigned count=n==1?36U:24U;
    for(unsigned i=0;i<count;++i) {
        lv_obj_t *o=n==0?lv_label_create(area_):lv_obj_create(area_);
        obj_[i]=o;
        if(n==0) {
            lv_label_set_text_fmt(o,"TXT%02u-%05u",i,0U);
            lv_obj_set_style_text_color(o,lv_color_hex(0xE3F5FA),0);
            lv_obj_set_pos(o,10+(int)(i%4)*(w-30)/4,10+(int)(i/4)*(h-30)/6);
        } else {
            lv_obj_set_size(o,n==2?70:48,n==2?70:48);
            lv_obj_set_style_radius(o,n==2?18:4,0);
            lv_obj_set_style_border_width(o,0,0);
            lv_obj_set_style_pad_all(o,0,0);
            lv_obj_set_style_bg_color(o,lv_color_hex(0x238AD2+(i%4)*0x110600),0);
            lv_obj_set_style_bg_opa(o,n==2?LV_OPA_50:LV_OPA_COVER,0);
            lv_obj_set_pos(o,(int)(i%6)*(w-80)/6,(int)(i/6)*(h-80)/6);
        }
    }
}
void XDOSBenchmark::Animate() {
    const int w=lv_obj_get_width(area_)>100?lv_obj_get_width(area_):900;
    const int h=lv_obj_get_height(area_)>100?lv_obj_get_height(area_):500;
    if(scene_==0) {
        for(unsigned i=0;i<24;++i)lv_label_set_text_fmt(obj_[i],"TXT%02u-%05u",i,step_+i*7);
    } else if(scene_==1||scene_==2) {
        unsigned count=scene_==1?36U:24U;
        for(unsigned i=0;i<count;++i) {
            lv_obj_set_pos(obj_[i],(int)((step_*7+i*17)%(unsigned)(w-72)),
                               (int)((step_*3+i*31)%(unsigned)(h-74)));
            if(scene_==2)
                lv_obj_set_style_bg_opa(obj_[i],(lv_opa_t)(85+(step_*3+i*13)%150),0);
        }
    } else {
        unsigned t=step_*23;
        lv_obj_set_style_bg_color(area_,lv_color_hex(((t&255)<<16)|(((t*5)&255)<<8)|((t*11)&255)),0);
    }
}
void XDOSBenchmark::Tick(unsigned now) {
    if(!active_||complete_)return;
    if(now-lastUpdateUs_>=FRAME_US){lastUpdateUs_=now;++step_;Animate();}
    if(!measuring_ && now-startUs_>=WARMUP_US) {
        measuring_=true;measureUs_=now;Reset();
    }
    if(measuring_ && now-measureUs_>=RUN_US) {CompleteScene(now);return;}
    if(now-lastInfoUs_>=1000000U) {
        lastInfoUs_=now;char line[130];
        unsigned sec=(measuring_?now-measureUs_:now-startUs_)/1000000U;
        snprintf(line,sizeof line,"%u/4 %s   %s %us / %us   refresh target 20ms",
                 scene_+1,Name(scene_),measuring_?"MEASURE":"WARMUP",sec,measuring_?10U:2U);
        lv_label_set_text(info_,line);
    }
}
void XDOSBenchmark::CompleteScene(unsigned now) {
    Sample &r=samples_[scene_];
    r.durationMs=(now-measureUs_)/1000U;r.frames=renderCount_;
    r.fps10=r.durationMs?(unsigned)((uint64_t)renderCount_*10000U/r.durationMs):0;
    r.renderAvg=renderCount_?(unsigned)(renderTotal_/renderCount_):0;
    r.renderMax=renderMax_;r.flushCalls=flushCount_;
    r.flushAvg=flushCount_?(unsigned)(flushTotal_/flushCount_):0;
    r.flushMax=flushMax_;
    r.dmaCalls=xdos_p0_dma_completed-dmaBaseCount_;
    r.dmaAvg=r.dmaCalls?(xdos_p0_dma_total_us-dmaBaseTotal_)/r.dmaCalls:0;
    r.dirtyPixels=xdos_p0_dirty_pixels-dirtyBase_;
    r.cpuFlushes=xdos_p0_cpu_flushes-cpuBase_;
    char line[250];
    snprintf(line,sizeof line,"[XDOS BENCH] %-12s FPS=%u.%u frames=%u render_avg=%uus render_max=%uus flush_avg=%uus flush_max=%uus calls=%u\r\n",
             Name(scene_),r.fps10/10,r.fps10%10,r.frames,r.renderAvg,r.renderMax,
             r.flushAvg,r.flushMax,r.flushCalls);
    Log(line);
    char dmaLine[192];
    snprintf(dmaLine,sizeof dmaLine,"[XDOS P0] %s DMA=%u avg=%uus CPUflush=%u dirty=%u pixels\r\n",
        Name(scene_),r.dmaCalls,r.dmaAvg,r.cpuFlushes,r.dirtyPixels);
    Log(dmaLine);
    ++scene_;
    if(scene_==SCENES){Finish();return;}
    step_=0;measuring_=false;startUs_=lastUpdateUs_=lastInfoUs_=now;
    Reset();MakeScene(scene_);
}
bool XDOSBenchmark::Export() {
    FRESULT fr=f_mkdir("SD:/XDOS");if(fr!=FR_OK&&fr!=FR_EXIST)return false;
    fr=f_mkdir("SD:/XDOS/BENCH");if(fr!=FR_OK&&fr!=FR_EXIST)return false;
    FIL f;fr=f_open(&f,"SD:/XDOS/BENCH/BENCH.CSV",FA_WRITE|FA_OPEN_APPEND);
    if(fr!=FR_OK)return false;
    bool ok=true;UINT nw=0;
    if(f_size(&f)==0) {
        const char *header="version,board,resolution,depth,scene,measured_ms,frames,fps_x10,render_avg_us,render_max_us,flush_calls,flush_avg_us,flush_max_us\n";
        fr=f_write(&f,header,(UINT)strlen(header),&nw);
        if(fr!=FR_OK||nw!=(UINT)strlen(header))ok=false;
    }
    lv_display_t *disp=lv_display_get_default();
    const unsigned w=disp?(unsigned)lv_display_get_horizontal_resolution(disp):0;
    const unsigned h=disp?(unsigned)lv_display_get_vertical_resolution(disp):0;
    for(unsigned i=0;i<SCENES&&ok;++i) {
        const Sample &r=samples_[i];char line[220];
        const int n=snprintf(line,sizeof line,"0.6.2-RC2,RPi3,\"%ux%u\",16,%s,%u,%u,%u,%u,%u,%u,%u,%u\n",
            w,h,Name(i),r.durationMs,r.frames,r.fps10,r.renderAvg,r.renderMax,r.flushCalls,r.flushAvg,r.flushMax);
        if(n<=0 || (unsigned)n>=sizeof line){ok=false;break;}
        fr=f_write(&f,line,(UINT)n,&nw);if(fr!=FR_OK||nw!=(UINT)n)ok=false;
    }
    if(ok && f_sync(&f)!=FR_OK)ok=false;
    if(f_close(&f)!=FR_OK)ok=false;
    return ok;
}
// Keep BENCH.CSV's RC1 column format unchanged for FPS A/B comparisons.
// The extra async-DMA and dirty statistics are written to P0DMA.CSV separately.
bool XDOSBenchmark::ExportP0() {
    FRESULT fr=f_mkdir("SD:/XDOS");if(fr!=FR_OK&&fr!=FR_EXIST)return false;
    fr=f_mkdir("SD:/XDOS/BENCH");if(fr!=FR_OK&&fr!=FR_EXIST)return false;
    FIL f;fr=f_open(&f,"SD:/XDOS/BENCH/P0DMA.CSV",FA_WRITE|FA_OPEN_APPEND);
    if(fr!=FR_OK)return false;
    bool ok=true;UINT nw=0;
    if(f_size(&f)==0) {
        const char *header="version,board,scene,dma_completed,dma_avg_us,cpu_flushes,dirty_pixels,dirty_percent_x100,buffer_rows,dma_threshold_pixels\n";
        fr=f_write(&f,header,(UINT)strlen(header),&nw);
        if(fr!=FR_OK||nw!=(UINT)strlen(header))ok=false;
    }
    lv_display_t *disp=lv_display_get_default();
    const unsigned w=disp?(unsigned)lv_display_get_horizontal_resolution(disp):0;
    const unsigned h=disp?(unsigned)lv_display_get_vertical_resolution(disp):0;
    for(unsigned i=0;i<SCENES && ok;++i) {
        const Sample &r=samples_[i];char line[220];
        const uint64_t total=(uint64_t)r.frames*w*h;
        const unsigned ratio=total?(unsigned)((uint64_t)r.dirtyPixels*10000ULL/total):0;
        const int n=snprintf(line,sizeof line,
            "0.6.2-RC2,RPi3,%s,%u,%u,%u,%u,%u,%u,%u\n",
            Name(i),r.dmaCalls,r.dmaAvg,r.cpuFlushes,r.dirtyPixels,ratio,
            (unsigned)XDOS_P0_BUFFER_ROWS_REPORT,(unsigned)XDOS_P0_MIN_DMA_PIXELS_REPORT);
        if(n<=0 || (unsigned)n>=sizeof line){ok=false;break;}
        fr=f_write(&f,line,(UINT)n,&nw);if(fr!=FR_OK||nw!=(UINT)n)ok=false;
    }
    if(ok && f_sync(&f)!=FR_OK)ok=false;
    if(f_close(&f)!=FR_OK)ok=false;
    return ok;
}
void XDOSBenchmark::Finish() {
    complete_=true;measuring_=false;
    lv_obj_clean(area_);lv_obj_set_style_bg_color(area_,lv_color_hex(0x203349),0);
    lv_obj_t *text=lv_label_create(area_);
    lv_label_set_long_mode(text,LV_LABEL_LONG_WRAP);
    lv_obj_set_width(text,lv_pct(96));lv_obj_set_pos(text,10,10);
    unsigned used=0;
    used=(unsigned)snprintf(result_,sizeof result_,"XD OS BENCHMARK 0.6.2-RC2 | 4 x 10 sec measured\n\n");
    for(unsigned i=0;i<SCENES&&used<sizeof result_-180;++i){
        const Sample &r=samples_[i];
        int n=snprintf(result_+used,sizeof result_-used,
            "%-12s FPS %u.%u   frames %u   render avg %uus   flush avg %uus (%u calls)\n",
            Name(i),r.fps10/10,r.fps10%10,r.frames,r.renderAvg,r.flushAvg,r.flushCalls);
        if(n>0)used+=(unsigned)n;
    }
    bool saved=Export();
    bool savedP0=ExportP0();
    if(used<sizeof result_-150)
        snprintf(result_+used,sizeof result_-used,"\nFPS CSV: %s\nP0 DMA CSV: %s",
                 saved?"BENCH.CSV":"NOT SAVED", savedP0?"P0DMA.CSV":"NOT SAVED");
    lv_label_set_text(text,result_);
    lv_label_set_text(info_,"BENCHMARK COMPLETED - CLICK BACK / STOP");
    Log("[XDOS BENCH] FINISHED\r\n");
    if(desktop_)desktop_->ReportAppResult(result_);
}
