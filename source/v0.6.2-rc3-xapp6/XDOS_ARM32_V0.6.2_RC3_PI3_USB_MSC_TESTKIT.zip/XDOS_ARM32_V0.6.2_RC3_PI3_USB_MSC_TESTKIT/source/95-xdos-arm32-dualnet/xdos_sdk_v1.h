#ifndef XDOS_SDK_V1_H
#define XDOS_SDK_V1_H
/* Stable AAPCS32 C ABI for external XD OS ARM32 apps. No C++/Circle headers. */
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#define XDOS_ABI_VERSION 1u
#define XDOS_XAPP_MAX_SIZE (64u*1024u)
/* Struct ABI offsets for AArch32: 0, 4, 8, 12, 16. */
typedef struct XdosHostApiV1 {
    uint32_t abi_version;
    uint32_t struct_bytes;
    void *context;
    void (*log)(void *context, const char *message);
    int32_t (*show_lvgl_demo)(void *context);
    /* V1 extension, available when struct_bytes >= 24. Existing apps keep working. */
    int32_t (*show_lvgl_benchmark)(void *context);
} XdosHostApiV1;
typedef int32_t (*XdosAppEntryV1)(const XdosHostApiV1 *api);
/* file header, little endian; size fixed to 32 bytes */
typedef struct XdosXappHeaderV1 {
    uint8_t magic[4];       /* X D A P */
    uint32_t abi_version;   /* 1 */
    uint32_t header_bytes;  /* 32 */
    uint32_t image_bytes;
    uint32_t entry_offset;
    uint32_t flags;         /* must be 0 */
    uint32_t checksum;      /* reserved, must be 0 in v1 */
    uint32_t reserved;       /* must be 0 */
} XdosXappHeaderV1;
#ifdef __cplusplus
}
static_assert(sizeof(XdosXappHeaderV1)==32,"XAPP header ABI mismatch");
#if defined(__arm__) && !defined(__aarch64__)
static_assert(sizeof(XdosHostApiV1)==24,"ARM32 host ABI mismatch");
#endif
#endif
#endif
