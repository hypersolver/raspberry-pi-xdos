#ifndef XDOS_LVGL_BENCH_H
#define XDOS_LVGL_BENCH_H
#include <lvgl/lvgl.h>
#include <stdint.h>
class Desktop;
class CSerialDevice;

// Fixed workload benchmark, run only in LVGL's owner GUI task.
class XDOSBenchmark {
public:
    XDOSBenchmark();
    bool Start(lv_obj_t *home, Desktop *desktop, CSerialDevice *serial);
    void Tick(unsigned nowUs);
    bool Running() const {return active_;}
private:
    enum { SCENES=4, OBJECTS=36 };
    struct Sample { unsigned durationMs,frames,fps10,renderAvg,renderMax,flushCalls,flushAvg,flushMax,dmaCalls,dmaAvg,dirtyPixels,cpuFlushes; };
    static void DisplayCallback(lv_event_t *event);
    static void BackCallback(lv_event_t *event);
    void OnDisplay(lv_event_t *event);
    void Reset();
    void MakeScene(unsigned n);
    void Animate();
    void CompleteScene(unsigned now);
    void Finish();
    void Back();
    bool Export();
    bool ExportP0();
    void Log(const char *s);
    static const char *Name(unsigned n);
    lv_obj_t *home_, *screen_, *area_, *info_, *report_;
    lv_obj_t *obj_[OBJECTS];
    Desktop *desktop_;
    CSerialDevice *serial_;
    bool active_, complete_, registered_;
    unsigned scene_, step_, startUs_, measureUs_, lastUpdateUs_, lastInfoUs_;
    bool measuring_;
    unsigned renderStart_, flushStart_, renderCount_,flushCount_,renderMax_,flushMax_;
    uint64_t renderTotal_,flushTotal_;
    unsigned dmaBaseCount_,dmaBaseTotal_,dirtyBase_,cpuBase_;
    Sample samples_[SCENES];
    char result_[1900];
};
#endif
