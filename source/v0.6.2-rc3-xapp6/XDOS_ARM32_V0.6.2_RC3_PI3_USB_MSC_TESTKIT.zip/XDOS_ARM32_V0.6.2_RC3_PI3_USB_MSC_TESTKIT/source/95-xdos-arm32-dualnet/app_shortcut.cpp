#include "app_shortcut.h"
#include "xapp_loader.h"
#include <fatfs/ff.h>
#include <string.h>

namespace {
static const char kManifest[] = "SD:/XDOS/APPS/LVGLDEMO.APP";
static const char kBenchManifest[] = "SD:/XDOS/APPS/LVGLBENCH.APP";
static const char kTrustedModule[] = "SD:/XDOS/APPS/LVGLDEMO.XAPP";
static const char kBenchModule[] = "SD:/XDOS/APPS/LVGLBENCH.XAPP";

// Minimal and deliberately strict .APP parser: only the approved LVGLDEMO
// executable can run in privileged mode (no memory isolation in SDK v1).
static bool VerifyManifest(const char *manifest, const char *module)
{
    FIL file;
    if (f_open(&file,manifest,FA_READ)!=FR_OK) return false;
    if (f_size(&file)==0 || f_size(&file)>1024) {f_close(&file);return false;}
    char text[1025];
    UINT got=0;
    const FRESULT r=f_read(&file,text,(UINT)f_size(&file),&got);
    const FRESULT closed=f_close(&file);
    if(r!=FR_OK || closed!=FR_OK || !got || got>1024) return false;
    for(UINT i=0;i<got;i++) if(text[i]==0) return false;
    text[got]=0;
    bool section=false, exec=false,abi=false,arch=false;
    char *cur=text;
    while(*cur) {
        char *end=cur;
        while(*end && *end!='\n')end++;
        char term=*end; *end=0;
        if(end>cur && end[-1]=='\r')end[-1]=0;
        if(!strcmp(cur,"[Application]"))section=true;
        else if(section && !strncmp(cur,"Exec=",5))exec=(!strcmp(cur+5,module));
        else if(section && !strncmp(cur,"ABI=",4))abi=(!strcmp(cur+4,"1"));
        else if(section && !strncmp(cur,"Arch=",5))arch=(!strcmp(cur+5,"armv7-a32"));
        cur=term ? end+1 : end;
    }
    return section&&exec&&abi&&arch;
}
}

const char *XdosRunLVGLShortcut(const XdosHostApiV1 *api)
{
    if(!VerifyManifest(kManifest,kTrustedModule))return "XAPP: LVGLDEMO.APP missing or invalid";
    switch(XappLoaderV1::ExecuteFile(kTrustedModule,api)) {
    case XappLoaderV1::OK:return "XAPP: LVGLDEMO.XAPP launched";
    case XappLoaderV1::OPEN_FAILED:return "XAPP: file not found on FAT32";
    case XappLoaderV1::SIZE_INVALID:return "XAPP: unsupported size";
    case XappLoaderV1::READ_FAILED:return "XAPP: SD read error";
    case XappLoaderV1::FORMAT_INVALID:return "XAPP: malformed or incompatible ABI";
    case XappLoaderV1::MEMORY_FAILED:return "XAPP: not enough RAM";
    case XappLoaderV1::ENTRY_ERROR:return "XAPP: module returned error";
    default:return "XAPP: unknown loader error";
    }
}

const char *XdosRunBenchmarkShortcut(const XdosHostApiV1 *api)
{
    if (!VerifyManifest(kBenchManifest,kBenchModule))
        return "XAPP: LVGLBENCH.APP missing or invalid (SD:/XDOS/APPS/)";
    switch(XappLoaderV1::ExecuteFile(kBenchModule,api)) {
    case XappLoaderV1::OK:return "XAPP: LVGLBENCH.XAPP started";
    case XappLoaderV1::OPEN_FAILED:return "XAPP: benchmark module missing";
    case XappLoaderV1::FORMAT_INVALID:return "XAPP: benchmark ABI invalid";
    case XappLoaderV1::MEMORY_FAILED:return "XAPP: benchmark exec slot unavailable";
    default:return "XAPP: benchmark load/execute failure";
    }
}
