#include "storage.h"
#include "desktop.h"
#include "usb_storage_policy.h"
#include <circle/devicenameservice.h>
#include <circle/timer.h>
#include <circle/sched/scheduler.h>
#include <circle/string.h>
#include <fatfs/ff.h>
#include <string.h>

namespace {
static const char kAppFolder[] = "SD:/XDOS";
static const char kNoteFile[]  = "SD:/XDOS/NOTE.TXT";
static const char kTempFile[]  = "SD:/XDOS/NOTE.TMP";
static const char kBackupFile[]= "SD:/XDOS/NOTE.BAK";
static const char kUSBRoot[]="USB:/";
static const char kUSBVolume[]="USB:";

// No paths or traversal from Terminal are accepted: CAT can read only
// simple filenames beneath SD:/XDOS; SAVE only writes NOTE.TXT.
static bool IsSafeName(const char *name)
{
    if(!name || !*name || strlen(name)>48) return false;
    if(strstr(name,"..")) return false;
    for(const char *p=name;*p;p++) {
        char c=*p;
        if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||
             (c>='0'&&c<='9')||c=='.'||c=='_'||c=='-')) return false;
    }
    return true;
}

static bool MakeCatPath(char *dest,unsigned cap,const char *name)
{
    if(!IsSafeName(name)) return false;
    const unsigned base=(unsigned)strlen(kAppFolder)+1;
    const unsigned n=(unsigned)strlen(name);
    if(base+n+1>cap)return false;
    strcpy(dest,kAppFolder);strcat(dest,"/");strcat(dest,name);
    return true;
}

static bool Append(char *dest,unsigned capacity,unsigned &used,const char *text)
{
    unsigned n=(unsigned)strlen(text);
    if(used+n+1>capacity)return false;
    memcpy(dest+used,text,n);
    used+=n;dest[used]=0;
    return true;
}

static bool ListDirectory(const char *path,char *result,unsigned capacity,
                          unsigned &length,FRESULT &error)
{
    DIR dir;
    FILINFO info;
    error=f_opendir(&dir,path);
    if(error==FR_NO_PATH && !strcmp(path,kAppFolder)) {
        length=0;result[0]=0;
        Append(result,capacity,length,"SD:/XDOS/ is empty. SAVE a note to create it.\n");
        error=FR_OK;
        return true;
    }
    if(error!=FR_OK)return false;
    length=0;result[0]=0;
    CString title;
    title.Format("Directory: %s\n",path);
    Append(result,capacity,length,(const char *)title);
    unsigned count=0;
    while(1) {
        error=f_readdir(&dir,&info);
        if(error!=FR_OK)break;
        if(!info.fname[0])break;
        CString line;
        if(info.fattrib&AM_DIR)
            line.Format("[DIR] %s\n",info.fname);
        else
            line.Format("%6lu %s\n",(unsigned long)info.fsize,info.fname);
        if(!Append(result,capacity,length,(const char *)line)) {
            Append(result,capacity,length,"... more entries (list truncated)\n");
            break;
        }
        count++;
    }
    FRESULT closing=f_closedir(&dir);
    if(error==FR_OK)error=closing;
    if(error!=FR_OK)return false;
    if(!count)Append(result,capacity,length,"(empty)\n");
    return true;
}

static bool ReadFile(const char *path,char *result,unsigned capacity,
                     unsigned &length,FRESULT &error)
{
    FIL file;
    error=f_open(&file,path,FA_READ);
    if(error!=FR_OK)return false;
    if(f_size(&file)>=capacity) {
        f_close(&file);
        error=FR_INVALID_OBJECT; // Our application-level size limit.
        return false;
    }
    UINT got=0;
    error=f_read(&file,result,capacity-1,&got);
    FRESULT closeError=f_close(&file);
    if(error==FR_OK)error=closeError;
    if(error!=FR_OK)return false;
    length=got;result[length]=0;
    return true;
}

static bool WriteUSBFile(const char *name,const char *data,unsigned length,FRESULT &error)
{
    char path[64];
    if(!XdosUSBMakePath(path,sizeof(path),name)) {
        error=FR_INVALID_NAME;return false;
    }
    if(!data || length==0 || length>120) {
        error=FR_INVALID_PARAMETER;return false;
    }
    FIL file;
    error=f_open(&file,path,FA_CREATE_ALWAYS|FA_WRITE);
    if(error!=FR_OK)return false;
    UINT written=0;
    error=f_write(&file,data,length,&written);
    if(error==FR_OK && written!=length)error=FR_DISK_ERR;
    if(error==FR_OK)error=f_sync(&file);
    const FRESULT cr=f_close(&file);
    if(error==FR_OK)error=cr;
    return error==FR_OK;
}

static bool SaveNote(const char *data,unsigned length,FRESULT &error)
{
    if(length>2047) {error=FR_INVALID_OBJECT;return false;}
    error=f_mkdir(kAppFolder);
    if(error!=FR_OK && error!=FR_EXIST)return false;
    FIL file;
    // Write new contents under a temporary filename first. The boot partition
    // and the previous NOTE.TXT remain unchanged during this stage.
    error=f_open(&file,kTempFile,FA_CREATE_ALWAYS|FA_WRITE);
    if(error!=FR_OK)return false;
    UINT written=0;
    error=f_write(&file,data,length,&written);
    if(error==FR_OK && written!=length)error=FR_DISK_ERR;
    if(error==FR_OK)error=f_sync(&file);
    FRESULT closeError=f_close(&file);
    if(error==FR_OK)error=closeError;
    if(error!=FR_OK)return false;

    // Keep one previous version as NOTE.BAK. FAT32 does not guarantee atomic
    // rename on power failure; this is a recovery aid, not a transaction.
    FRESULT bakDelete=f_unlink(kBackupFile);
    if(bakDelete!=FR_OK && bakDelete!=FR_NO_FILE) {error=bakDelete;return false;}
    FRESULT oldRename=f_rename(kNoteFile,kBackupFile);
    if(oldRename!=FR_OK && oldRename!=FR_NO_FILE) {
        error=oldRename;
        return false;
    }
    error=f_rename(kTempFile,kNoteFile);
    if(error!=FR_OK) {
        if(oldRename==FR_OK)f_rename(kBackupFile,kNoteFile);
        return false;
    }
    return true;
}
}

CStorageTask::CStorageTask(Desktop *desktop)
: CTask(64*1024), desktop_(desktop), lastUSBDevice_(0),
  usbMounted_(false), usbEjected_(false)
{
    memset(&usbFS_,0,sizeof(usbFS_));
    SetName("xdos-storage");
}

FRESULT CStorageTask::MountUSB()
{
    if(usbMounted_)return FR_OK;
    CDevice *dev=CDeviceNameService::Get()->GetDevice("umsd1",true);
    if(!dev) {
        desktop_->SetUSBStorage(false,"USB: NO DEVICE");
        return FR_NOT_READY;
    }
    lastUSBDevice_=dev;
    // opt=1 validates the FAT volume and binds FatFs diskio to umsd1.
    // No Linux; USB MSC and the SCSI transport remain managed by Circle.
    const FRESULT fr=f_mount(&usbFS_,kUSBVolume,1);
    if(fr==FR_OK) {
        usbMounted_=true;
        usbEjected_=false;
        desktop_->SetUSBStorage(true,"USB: FAT MOUNTED (USB:/)");
    } else if(fr==FR_NO_FILESYSTEM) {
        desktop_->SetUSBStorage(false,"USB: UNSUPPORTED FS (FAT16/32 ONLY)");
    } else {
        desktop_->SetUSBStorage(false,"USB: FAT MOUNT FAILED");
    }
    return fr;
}

FRESULT CStorageTask::EjectUSB()
{
    // All USB file handles are closed before entering this function; the
    // storage task serializes commands. This logically unmounts the FS.
    // Physical USB power/disconnect is NOT requested.
    const FRESULT fr=f_mount(0,kUSBVolume,0);
    if(fr==FR_OK) {
        usbMounted_=false;
        usbEjected_=true;
        desktop_->SetUSBStorage(false,"USB: SAFE TO REMOVE (UNMOUNTED)");
    }
    return fr;
}

void CStorageTask::PollUSB()
{
    CDevice *dev=CDeviceNameService::Get()->GetDevice("umsd1",true);
    if(!dev) {
        if(lastUSBDevice_ || usbMounted_ || usbEjected_) {
            f_mount(0,kUSBVolume,0); // no disk I/O
            lastUSBDevice_=0;
            usbMounted_=false;
            usbEjected_=false;
            desktop_->SetUSBStorage(false,"USB: DISCONNECTED");
        }
        return;
    }
    if(dev!=lastUSBDevice_) {
        if(usbMounted_)f_mount(0,kUSBVolume,0);
        lastUSBDevice_=dev;
        usbMounted_=false;
        usbEjected_=false;
    }
    if(!usbMounted_ && !usbEjected_)MountUSB();
}

void CStorageTask::Run(void)
{
    Desktop::StorageRequest request;
    char buffer[4096];
    unsigned lastUSBPoll=CTimer::GetClockTicks()-3000000U;
    while(1) {
        const unsigned now=CTimer::GetClockTicks();
        if((unsigned)(now-lastUSBPoll)>=3000000U) {
            PollUSB();
            lastUSBPoll=now;
        }
        if(!desktop_->TakeStorageRequest(request)) {
            CScheduler::Get()->MsSleep(25);
            continue;
        }
        unsigned length=0;
        FRESULT error=FR_OK;
        bool ok=false;
        const char *data=0;
        const char *operation="FAT32";
        CString message;
        switch(request.action) {
        case Desktop::StorageUSBMount:
            operation="USB MOUNT";
            usbEjected_=false;
            error=MountUSB();
            ok=error==FR_OK;
            break;
        case Desktop::StorageUSBEject:
            operation="USB EJECT";
            error=EjectUSB();
            ok=error==FR_OK;
            break;
        case Desktop::StorageUSBList:
            operation="USB LS";
            if(!usbMounted_) {error=FR_NOT_READY;break;}
            ok=ListDirectory(kUSBRoot,buffer,sizeof(buffer),length,error);
            data=buffer;
            break;
        case Desktop::StorageUSBCat: {
            operation="USB CAT";
            if(!usbMounted_) {error=FR_NOT_READY;break;}
            char path[64];
            if(!XdosUSBMakePath(path,sizeof(path),request.filename)) {
                error=FR_INVALID_NAME;break;
            }
            ok=ReadFile(path,buffer,sizeof(buffer),length,error);
            data=buffer;
            break;
        }
        case Desktop::StorageUSBWrite:
            operation="USB WRITE";
            if(!usbMounted_) {error=FR_NOT_READY;break;}
            ok=WriteUSBFile(request.filename,request.data,request.length,error);
            break;
        case Desktop::StorageList:
        case Desktop::StorageListRoot:
            operation="LIST";
            ok=ListDirectory(request.action==Desktop::StorageListRoot?
                             "SD:/":kAppFolder,buffer,sizeof(buffer),length,error);
            data=buffer;
            break;
        case Desktop::StorageLoadNote:
            operation="LOAD NOTE.TXT";
            ok=ReadFile(kNoteFile,buffer,2048,length,error);
            data=buffer;
            break;
        case Desktop::StorageSaveNote:
            operation="SAVE NOTE.TXT";
            ok=SaveNote(request.data,request.length,error);
            break;
        case Desktop::StorageCat: {
            operation="CAT";
            char path[96];
            if(!MakeCatPath(path,sizeof(path),request.filename)) {
                error=FR_INVALID_NAME;
                break;
            }
            ok=ReadFile(path,buffer,sizeof(buffer),length,error);
            data=buffer;
            break;
        }
        default:
            error=FR_INVALID_PARAMETER;
            break;
        }
        if(ok) message.Format("%s: OK",operation);
        else if(error==FR_INVALID_OBJECT)
            message.Format("%s: file exceeds buffer limit (or invalid file)",operation);
        else
            message.Format("%s: FAT32 error %u",operation,(unsigned)error);
        desktop_->StorageCompleted(request.action,ok,(const char*)message,
                                   ok?data:0,ok?length:0);
        // After I/O errors, periodically try to remount if the stick is still
        // present; never endlessly retry the same failing request.
        if(!ok && request.action>=Desktop::StorageUSBList &&
           request.action<=Desktop::StorageUSBWrite && error==FR_NOT_READY) {
            usbMounted_=false;
            desktop_->SetUSBStorage(false,"USB: REMOVED OR NOT READY");
        }
    }
}
