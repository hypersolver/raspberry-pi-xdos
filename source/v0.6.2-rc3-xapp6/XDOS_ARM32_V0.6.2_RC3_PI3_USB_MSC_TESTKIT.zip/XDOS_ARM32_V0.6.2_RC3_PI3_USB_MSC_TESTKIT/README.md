# XD OS ARM32 v0.6.2-RC3 — USB Mass Storage Test Kit (Raspberry Pi 3B/3B+)

This RC3 is based on **v0.6.2-RC2 P0 GUI Test Kit**. USB MSC integration adds mount, read/write, safe logical unmount and hotplug status while preserving the LVGL Benchmark, Arduino Native, FAT32 SD, XAPP, DMA and Windows build/deploy workflow.

## Starting point
- Target: RPi 3B/3B+ AArch32 bare-metal; RPi 4 Ubuntu ARM64 is the build host only.
- USB host transport: Circle's existing USB Bulk-Only Mass Storage (SCSI) driver; FatFs `USB:` -> `umsd1`.
- File system: FAT16/FAT32 on 512-byte logical sector; first USB device only. No exFAT, NTFS, UASP-only.
- LVGL home: USB status label, USB LIST/EJECT buttons, USB keyboard terminal entry.
- Terminal commands: `usb status`, `usb ls`, `usb cat FILE.TXT`, `usb write FILE.TXT text`, `usb mount`, `usb eject`.
- USB mount deferred after first desktop frame in storage task; Circle USB host initialization still synchronous before desktop.
- Windows deployment scripts now use RC3 names, and build matrix output is version-tagged RC3.

## Build on Raspberry Pi 4
```bash
bash tests/run-host-tests.sh
bash tests/run-lvgl-syntax-check.sh
bash tests/run-usb-mock-syntax-check.sh
bash tests/run-desktop-mock-syntax-check.sh
bash build-on-rpi4.sh
```
Build `.img`: `output/xdos32-v062-rc3-pi3.img` (not precompiled in this ZIP).

See **README_USB_MSC_ZH.md** for detailed setup and safe testing, **TEST_PLAN_ZH.md** for the original P0 benchmark sequence.

## Verification
Unit/mock-header checks and packaging are not equivalent to a full Circle link or hardware bring-up. Raspberry Pi 3B USB MSC and FatFs hot-remove remain **unverified**. Avoid production files until validated on an empty FAT32 USB stick.

USB-UART, USB Touch and MIPI DSI changes discussed in this conversation are separate work items; this RC3 specifically implements USB Mass Storage and retains the earlier RC2 kernel baseline.
