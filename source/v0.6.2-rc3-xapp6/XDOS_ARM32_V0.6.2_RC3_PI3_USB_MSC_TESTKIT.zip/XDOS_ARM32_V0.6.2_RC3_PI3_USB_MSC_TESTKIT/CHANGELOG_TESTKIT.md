# RC2 Test Kit Addendum

- Based on `XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI` unchanged kernel source and P0 patches.
- Added `build-test-matrix-on-rpi4.sh` to create distinct images for 32/64/96-line draw buffers and an optional threshold variant.
- Added `windows/Get-XDOS-RC2.ps1`, `Deploy-XDOS-RC2.ps1`, `Collect-XDOS-RC2.ps1` for checksum-verified Windows transfer, safe MicroSD deployment, and result collection.
- Added `tools/compare-matrix.py` to report latest complete four-scene FPS results with async-DMA metrics.
- **Not a new kernel release.** Real Pi4 cross-link/Pi3 hardware benchmarks require user execution.
