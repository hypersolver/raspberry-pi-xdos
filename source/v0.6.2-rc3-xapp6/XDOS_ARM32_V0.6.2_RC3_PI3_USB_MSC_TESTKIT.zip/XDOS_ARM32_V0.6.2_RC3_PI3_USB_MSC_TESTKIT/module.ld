OUTPUT_FORMAT("elf32-littlearm")
OUTPUT_ARCH(arm)
ENTRY(xapp_entry)
SECTIONS
{
    . = 0;
    .xapp_header : { KEEP(*(.xapp_header)) }
    . = ALIGN(4);
    .text : { *(.text*) *(.rodata*) }
    . = ALIGN(4);
    .data : { *(.data*) }
    /DISCARD/ : { *(.comment*) *(.note*) *(.ARM.attributes*) *(.ARM.exidx*) }
}
