# XD OS V0.6.2-RC2 Pi 3 對照測試計畫

本套件以 **RC2 原始碼不更動核心邏輯** 為原則，新增可重複的建置矩陣、SHA-256 追蹤與 Windows MicroSD 部署腳本。測試工具版本不代表新的核心功能發行版。

## 0. 測試範圍與安全

- 編譯：RPi 4，Ubuntu 24.04 ARM64，`~/xdos-build/circle` 必須為 `RASPPI=3`、`AARCH=32`。
- 執行：RPi 3B／3B+，XD OS ARM32 Bare-metal。
- 保留目前可開機的舊 `.img`，不要覆蓋。測試需備用 MicroSD，避免中斷 FAT32 寫入。
- 所有 Benchmark 使用同一張 SD、同樣鍵盤滑鼠、電源、網路連接狀態與 `1024×768 @ 60 Hz`，Framebuffer `16-bit RGB565`。
- 4 個場景固定：`TEXT_24`、`MOVE_36`、`ALPHA_24`、`FULL_REDRAW`；各暖機 2 秒、測 10 秒，約 48 秒。
- 目前 **沒有**宣稱 Circle 連結／DMA IRQ／RPi 3B 實測通過；須先在你的機器上做。

## 1. 首先只建置 64 行基準

```bash
cd ~/xdos-build/XDOS_ARM32_V0.6.2_RC2_PI3_TESTKIT
bash tests/run-host-tests.sh
bash tests/run-lvgl-syntax-check.sh
bash build-test-matrix-on-rpi4.sh --one 64 512
```

成功應有：
`output/matrix/r64-d512/xdos32-v062-rc2-r64-d512.img`、`.sha256`、`BUILD_INFO.txt`、`build.log`。

## 2. 從 Windows PowerShell 下載、部署

在 Windows 下載解壓測試套件後，切至其 `windows` 子資料夾：

```powershell
.\Get-XDOS-RC2.ps1 -Variant r64-d512
.\Deploy-XDOS-RC2.ps1 -Drive E: -Variant r64-d512
```

`E:` 是示範代號，必須換成實際 MicroSD 分割區。部署腳本會備份 `config.txt` 到 Windows、保留舊核心、只修改 `arm_64bit` 與 `kernel` 兩項、把 `.APP/.XAPP` 放至 **`XDOS\APPS`** 而非 `XDOS`。

Windows PowerShell 若拒絕執行 `.ps1`，可針對目前視窗暫時使用：

```powershell
Set-ExecutionPolicy -Scope Process Bypass
```

此指令僅影響目前 PowerShell Session；若有企業裝置管理政策，應遵循其限制。

## 3. RPi 3B 實機測試

1. 以 `xdos32-v062-rc2-r64-d512.img` 開機，確認桌面、鍵盤、滑鼠正常。
2. 打開 `LVGL BENCHMARK APP`，完成四場景（約 48 秒）。
3. 確認有產生 `SD:/XDOS/BENCH/BENCH.CSV` 和 `SD:/XDOS/BENCH/P0DMA.CSV`。
4. 記錄是否有當機、FPS 異常、閃爍、畫面遺失、Wi-Fi 斷線或 FAT32 寫入失敗。
5. 關機後安全退出 MicroSD，在 Windows 執行：

```powershell
.\Collect-XDOS-RC2.ps1 -Drive E: -Variant r64-d512
```

## 4. 若 64 行通過，再測 32／96 行

在 RPi 4：

```bash
bash build-test-matrix-on-rpi4.sh --one 32 512
bash build-test-matrix-on-rpi4.sh --one 96 512
# 可選：比較 DMA 閾值
bash build-test-matrix-on-rpi4.sh --one 64 1024
```

每個 `.img` 使用獨立檔名，並有 SHA/參數紀錄。逐一透過 Windows SCP 取回、MicroSD 複製、執行相同 Benchmark。**不要在不同 Buffer 參數間直接比較不同網路或 HDMI 模式的測試。**

## 5. 收集 CSV 後比較

可把每一次測試收集的資料夾傳到 RPi 4，執行：

```bash
python3 tools/compare-matrix.py ./RESULTS/r64-d512_時間 ./RESULTS/r32-d512_時間 ./RESULTS/r96-d512_時間
```

或直接將每一組 `BENCH.CSV`、`P0DMA.CSV` 上傳到這個對話，我可以幫你分析每個場景的 FPS、Render 平均值及 DMA 完成時間。

**重要：** `BENCH.CSV` 的 `flush_avg_us` 是 LVGL Flush callback 時間，不包含非同步 DMA 傳輸完成；對 DMA 延遲請看 `P0DMA.CSV` 的 `dma_avg_us`。`FPS` 為 LVGL Render FPS，不等於 HDMI 螢幕更新率。`Dirty %` 是更新像素量與完整幀像素量的比值，重疊區域可能重複計入。

## 6. 出問題時要回傳什麼

- 編譯失敗：`output/matrix/rXX-dYYY/build.log` 的**第一個** error 上下各 20 行。
- 開機異常：目前 `config.txt` 的 `kernel=`、畫面最後一行、是否能啟動舊版。
- LVGL 畫面停止：UART 最後訊息，DMA 是否完成、USB 是否還有反應。
- Benchmark 完成：CSV、使用的 `BUILD_INFO.txt`，以及當時有沒有連 Ethernet/Wi-Fi。

## 7. 修正界限

測試工具不修改核心及 RC2 P0 演算法。接下來是否改動 DMA 閾值、Buffer 大小、Dirty 合併與真正 DMA Wait Event 機制，取決於你的實測資料。DMA Busy 等待的現行修改採 Circle Scheduler 睡眠輪詢，**尚非完全 IRQ 事件驅動的無忙等**；須另行驗證後才能宣稱完全消除等待輪詢。


## RC3 USB 隨身碟補充測試

先使用**空白 FAT32、512-byte 邏輯磁區** USB 隨身碟。等桌面顯示後插入，查看 `USB: FAT MOUNTED` 狀態；測試 `usb ls`、`usb cat TEST.TXT`、`usb write XDOSTEST.TXT hello-from-XDOS`、`usb cat XDOSTEST.TXT`、`usb eject`。

Eject 成功後再拔除；重新插入後確認能再次掛載。報告是否出現卡住、寫入資料缺失或 USB 鼠鍵延遲。

完成 USB 功能測試後，再使用原本的四個固定場景跑 Benchmark，以便比較 RC2／RC3 是否出現 FPS 回歸。
