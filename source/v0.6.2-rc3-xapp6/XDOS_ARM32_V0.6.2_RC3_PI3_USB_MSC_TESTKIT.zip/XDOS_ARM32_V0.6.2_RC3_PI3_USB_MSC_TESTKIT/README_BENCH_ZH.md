RC1 Benchmark 場景仍維持不變，請參閱 `README_P0_ZH.md` 的比較流程。

本版操作請參閱 [README_P0_ZH.md](README_P0_ZH.md)，場景仍與 RC1 相同。
