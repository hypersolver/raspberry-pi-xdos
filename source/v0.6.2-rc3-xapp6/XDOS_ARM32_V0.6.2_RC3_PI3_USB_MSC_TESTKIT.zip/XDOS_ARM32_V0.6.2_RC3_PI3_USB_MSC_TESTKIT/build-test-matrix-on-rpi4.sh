#!/usr/bin/env bash
# XD OS 0.6.2 RC3 USB MSC build matrix; deliberately preserves known-good images.
# Runs on Raspberry Pi 4 / Ubuntu 24.04 ARM64, targets Raspberry Pi 3B AArch32.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MATRIX="$ROOT/output/matrix"
mkdir -p "$MATRIX"

help() {
  cat <<EOF
Usage:
  bash build-test-matrix-on-rpi4.sh --one 64 512
  bash build-test-matrix-on-rpi4.sh --quick        # 32,64,96 rows / threshold 512
  bash build-test-matrix-on-rpi4.sh --all          # plus 64 rows / threshold 1024
  bash build-test-matrix-on-rpi4.sh --one 64 512 --overwrite

Uses existing Circle source; RC3's build script patches it with backups.
Every variant stores an immutable kernel, SHA256, build log and manifest.
Do not run multiple builds in parallel (Circle sources are patched in place).
EOF
}
if [[ $# -lt 1 ]]; then help; exit 2; fi
mode="$1";shift
variants=()
case "$mode" in
  --one) [[ $# -ge 2 ]] || { help; exit 2; }; variants+=("$1:$2"); shift 2 ;;
  --quick) variants=('32:512' '64:512' '96:512') ;;
  --all) variants=('32:512' '64:512' '96:512' '64:1024') ;;
  --help|-h) help; exit 0 ;;
  *) help; exit 2 ;;
esac
overwrite=0
if [[ $# -gt 0 ]]; then
  if [[ "$1" == --overwrite && $# -eq 1 ]]; then overwrite=1; else help; exit 2; fi
fi
CIRCLE="${CIRCLE_HOME:-$HOME/xdos-build/circle}"
[[ -f "$CIRCLE/Rules.mk" ]] || { echo "Circle missing: $CIRCLE" >&2; exit 1; }
for tool in python3 sha256sum arm-none-eabi-readelf; do
  command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 1; }
done
for cfg in "${variants[@]}"; do
  rows="${cfg%%:*}"; threshold="${cfg##*:}"
  [[ "$rows" =~ ^[0-9]+$ && "$threshold" =~ ^[0-9]+$ ]] || { echo "Invalid variant $cfg" >&2; exit 2; }
  (( rows>=16 && rows<=256 && threshold>=64 && threshold<=4096 )) || { echo "Out of range $cfg" >&2; exit 2; }
  tag="r${rows}-d${threshold}"
  name="xdos32-v062-rc3-${tag}.img"
  dir="$MATRIX/$tag"
  if [[ -e "$dir/$name" && "$overwrite" -ne 1 ]]; then
    echo "Already exists: $dir/$name; use --overwrite to rebuild" >&2
    exit 1
  fi
  mkdir -p "$dir"
  echo "===== BUILD $tag (RPi3 ARM32) ====="
  # PIPESTATUS preserves the build's actual failure code (not tee's exit code).
  set +e
  (cd "$ROOT" && \
    XDOS_BUFFER_ROWS="$rows" \
    XDOS_DMA_MIN_PIXELS="$threshold" \
    CIRCLE_HOME="$CIRCLE" \
    bash ./build-on-rpi4.sh) 2>&1 | tee "$dir/build.log"
  rc="${PIPESTATUS[0]}"
  set -e
  if [[ "$rc" -ne 0 ]]; then
    echo "BUILD FAILED ($rc) for $tag. First error: grep -nE '(^| )error:|Error |undefined reference|FAILED' '$dir/build.log'" >&2
    exit "$rc"
  fi
  built="$ROOT/output/xdos32-v062-rc3-pi3.img"
  elf="$CIRCLE/sample/103-xdos-pi3-usb-msc/kernel8-32.elf"
  [[ -s "$built" && -s "$elf" ]] || { echo "Missing built kernel or ELF" >&2; exit 1; }
  arm-none-eabi-readelf -h "$elf" > "$dir/elf-header.txt"
  grep -q 'Class:.*ELF32' "$dir/elf-header.txt" || { echo 'Not ELF32' >&2; exit 1; }
  grep -q 'Machine:.*ARM' "$dir/elf-header.txt" || { echo 'Not ARM ELF' >&2; exit 1; }
  # Fail closed if the patch did not apply requested rows/threshold.
  lvfile="$CIRCLE/addon/lvgl/lvgl.cpp"
  grep -Eq "^#define XDOS_P0_BUFFER_ROWS ${rows}$" "$lvfile" || { echo 'Buffer rows mismatch' >&2; exit 1; }
  grep -Eq "^#define XDOS_P0_MIN_DMA_PIXELS ${threshold}$" "$lvfile" || { echo 'DMA threshold mismatch' >&2; exit 1; }
  cp "$built" "$dir/$name"
  (cd "$dir" && sha256sum "$name" > "$name.sha256")
  kernel_sha="$(sha256sum "$dir/$name" | awk '{print $1}')"
  circle_sha="$(git -C "$CIRCLE" rev-parse HEAD 2>/dev/null || printf UNKNOWN)"
  cat > "$dir/BUILD_INFO.txt" <<EOF
build=Xdos-ARM32-v0.6.2-RC3
variant=$tag
board=Raspberry Pi 3B/3B+
arch=AArch32 cortex-a53
buffer_rows=$rows
dma_min_pixels=$threshold
resolution_test_target=1024x768
color_depth_test_target=16
circle_commit=$circle_sha
circle_local_patches=YES
kernel_filename=$name
kernel_sha256=$kernel_sha
build_host=$(uname -m)
EOF
  echo "PASS: $dir/$name"
done
printf '\nAll requested builds completed. Copy variants individually; do not overwrite known-good images.\n'
