#!/usr/bin/env python3
import struct,sys,pathlib
p=pathlib.Path(sys.argv[1]);data=p.read_bytes()
assert len(data)>=32,'truncated'
magic,abi,hsize,size,entry,flags,check,reserved=struct.unpack_from('<4s7I',data,0)
assert magic==b'XDAP' and abi==1 and hsize==32
assert len(data)==size and 32<=entry<size and entry%4==0
assert flags==0 and check==0 and reserved==0
print(f'XAPP OK: size={len(data)}, entry_offset={entry}, ABI={abi}, ARM32')
