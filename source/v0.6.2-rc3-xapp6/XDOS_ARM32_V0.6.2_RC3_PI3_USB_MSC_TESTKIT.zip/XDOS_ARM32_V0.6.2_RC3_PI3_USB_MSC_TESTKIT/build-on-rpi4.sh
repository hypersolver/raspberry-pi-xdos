#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CIRCLE="${CIRCLE_HOME:-$HOME/xdos-build/circle}"
DEST="$CIRCLE/sample/103-xdos-pi3-usb-msc"
[[ -f "$CIRCLE/Rules.mk" ]] || { echo "Circle missing: $CIRCLE" >&2; exit 1; }
for tool in arm-none-eabi-gcc arm-none-eabi-g++ arm-none-eabi-objcopy arm-none-eabi-nm git python3 make; do
  command -v "$tool" >/dev/null || { echo "Missing: $tool" >&2; exit 1; }
done
mkdir -p "$ROOT/output" "$DEST"
# Fail early if this Circle revision lacks the USB MSC + FatFs hooks.
[[ -f "$CIRCLE/lib/usb/usbmassdevice.cpp" ]] || { echo 'Circle USB Mass Storage host driver missing.' >&2; exit 1; }
[[ -f "$CIRCLE/addon/fatfs/diskio.cpp" ]] || { echo 'Circle FatFs diskio.cpp missing.' >&2; exit 1; }
grep -q '"umsd1"' "$CIRCLE/addon/fatfs/diskio.cpp" || { echo 'Circle FatFs is missing umsd1 volume mapping.' >&2; exit 1; }
grep -q '"USB"' "$CIRCLE/addon/fatfs/ffconf.h" || { echo 'Circle FatFs is missing USB: volume.' >&2; exit 1; }
# Use existing Pi3 Config.mk/Config2.mk, fail if target mismatches.
if ! grep -Eq '^RASPPI[[:space:]]*=[[:space:]]*3([[:space:]]|$)' "$CIRCLE/Config.mk" "$CIRCLE/Config2.mk" 2>/dev/null; then
  echo 'Please configure Circle for Pi3: cd ~/xdos-build/circle && ./configure -r 3 -p arm-none-eabi-' >&2
  exit 1
fi
# Patch prior to library builds, fail closed on unexpected Circle source layouts.
python3 "$ROOT/tools/patch-circle-wfi.py" "$CIRCLE"
python3 "$ROOT/tools/patch-circle-tcp-connect.py" "$CIRCLE"
# The asynchronous path requires Circle's DMA code to be compiled.
if grep -Eq '(^|[[:space:]])-DNO_SCREEN_DMA_BURST_LENGTH' "$CIRCLE/Config.mk" "$CIRCLE/Config2.mk" 2>/dev/null; then
  echo 'P0 DMA requires SCREEN_DMA_BURST_LENGTH; disable NO_SCREEN_DMA_BURST_LENGTH.' >&2; exit 1
fi
python3 "$ROOT/tools/patch-circle-gfx-p0.py" "$CIRCLE"
# This DMA integration is designed only for AArch32 on Pi 3.
if ! grep -Eq '^AARCH[[:space:]]*=[[:space:]]*32([[:space:]]|$)' "$CIRCLE/Config.mk" "$CIRCLE/Config2.mk" 2>/dev/null; then
  echo 'Circle must be configured for AARCH=32 (RPi3 ARM32), not ARM64.' >&2; exit 1
fi
# Rebuild required dependencies for Pi 3, not Pi 4 or ARM64.
(cd "$CIRCLE" && ./makeall)
git -C "$CIRCLE" submodule update --init addon/wlan/hostap addon/lvgl/lvgl
make -C "$CIRCLE/lib" -j"${JOBS:-2}"
make -C "$CIRCLE/lib/sched" -j"${JOBS:-2}"
make -C "$CIRCLE/addon/SDCard" -j"${JOBS:-2}"
make -C "$CIRCLE/addon/fatfs" -j"${JOBS:-2}"
(cd "$CIRCLE/addon/wlan" && ./makeall --nosample)
make -C "$CIRCLE/addon/lvgl" -j"${JOBS:-2}"
cp -a "$ROOT/source/95-xdos-arm32-dualnet/." "$DEST/"
make -C "$DEST" clean
make -C "$DEST" -j"${JOBS:-2}" XDOS_GUI=lvgl XDOS_WIFI=1 XDOS_LVGL_PERF=1 \
  XDOS_BUFFER_ROWS="${XDOS_BUFFER_ROWS:-64}" XDOS_DMA_MIN_PIXELS="${XDOS_DMA_MIN_PIXELS:-512}"
python3 "$ROOT/tools/check-exec-section.py" "$DEST/kernel8-32.elf"
install -m 0644 "$DEST/kernel8-32.img" "$ROOT/output/xdos32-v062-rc3-pi3.img"
(cd "$ROOT/output" && sha256sum xdos32-v062-rc3-pi3.img > xdos32-v062-rc3-pi3.img.sha256)
bash "$ROOT/build-module-on-rpi4.sh"
echo "Build complete: $ROOT/output/xdos32-v062-rc3-pi3.img"
