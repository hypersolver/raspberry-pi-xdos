# XD OS ARM32 V0.6.2-RC3 — USB 隨身碟（RPi 3B／3B+）

延續 RC2 LVGL P0／Benchmark，新增 Circle USB MSC → FatFs `USB:` 掛載、讀寫、卸載、拔插狀態與 LVGL 快捷鍵。

**請優先閱讀 [`README_USB_MSC_ZH.md`](README_USB_MSC_ZH.md)**。

此 ZIP 是原始碼測試候選版，尚未在你的 RPi 4 完整連結 `.img`，也未在 RPi 3B 實測 USB 傳輸與拔除。
