#!/usr/bin/env python3
"""XDOS v0.6.2 RC2 Pi3 LVGL performance integration. Fail closed.

- LVGL partial invalidation stays native.
- Tiny dirty rectangles: synchronous RGB565 row-copy.
- Larger dirty rectangles: Circle's native IRQ-completion async DMA SetArea.
- Replace the single-DMA-slot busy-spin by yield to Circle scheduler.
- Runtime-adapted LVGL timer check, without adding a second LVGL runtime.

Use only with checked Circle source and RASPPI=3 AARCH=32; back up modified files.
"""
import os, re, shutil, sys
from pathlib import Path
if len(sys.argv) != 2:
    raise SystemExit('usage: patch-circle-gfx-p0.py /path/to/circle')
base=Path(sys.argv[1]); lv=base/'addon/lvgl/lvgl.cpp'; fb=base/'lib/bcmframebuffer.cpp'
source=Path(__file__).resolve().parents[1]/'source/95-xdos-arm32-dualnet/lvgl_flush_fast.h'
rows=int(os.environ.get('XDOS_BUFFER_ROWS','64'))
threshold=int(os.environ.get('XDOS_DMA_MIN_PIXELS','512'))
if not 16<=rows<=256 or not 64<=threshold<=4096:
    raise SystemExit('XDOS_BUFFER_ROWS 16..256; XDOS_DMA_MIN_PIXELS 64..4096')
if not all(p.exists() for p in (lv,fb,source)):
    raise SystemExit('Missing LVGL/Framebuffer Circle source or XDOS helper; unchanged')
old_lv=lv.read_text(); old_fb=fb.read_text()
# When RC1 CPU flush is already applied, restore exactly the Circle baseline
# captured by RC1 before applying the DMA-enabled P0 patch.
if '// XDOS_PI3_RGB565_FAST_V1' in old_lv:
    backup=lv.with_name('lvgl.cpp.xdos-original')
    if not backup.exists():
        raise SystemExit('Old RC1 fast-flush patched; missing exact baseline backup: '+str(backup))
    core=backup.read_text()
else:
    core=old_lv
if '// XDOS_P0_ASYNC_DMA_V2' in core:
    # Values may be updated for buffer A/B testing without touching other code.
    mod=re.sub(r'(?m)^#define XDOS_P0_BUFFER_ROWS \d+$',f'#define XDOS_P0_BUFFER_ROWS {rows}',core)
    mod=re.sub(r'(?m)^#define XDOS_P0_MIN_DMA_PIXELS \d+$',f'#define XDOS_P0_MIN_DMA_PIXELS {threshold}',mod)
    if mod==core and f'#define XDOS_P0_BUFFER_ROWS {rows}' not in core:
        raise SystemExit('P0 patch marker exists but constants missing; unchanged')
else:
    anchors=['#include <lvgl/lvgl.h>',
             'unsigned nBufSizePixels = nWidth * nHeight/10;',
             's_pThis->m_pDisplay->SetArea (Area, pBuffer, DisplayFlushComplete, pDisplay);',
             'void CLVGL::DisplayFlushComplete (void *pParam)',
             'if (nTicks - m_nLastUpdate >= 5*CLOCKHZ/1000)',
             'lv_timer_handler ();']
    for a in anchors:
        if core.count(a)!=1:
            raise SystemExit(f'Circle LVGL changed ({core.count(a)} matches): {a!r}; unchanged')
    mod=core.replace('#include <lvgl/lvgl.h>',
         '''#include <lvgl/lvgl.h>
#include "xdos_flush_fast.h" // XDOS_P0_ASYNC_DMA_V2
#define XDOS_P0_BUFFER_ROWS %d
#define XDOS_P0_MIN_DMA_PIXELS %d
// These totals are intentionally 32-bit: benchmark takes a difference each scene.
extern "C" {
volatile unsigned xdos_p0_dma_submitted = 0;
volatile unsigned xdos_p0_dma_completed = 0;
volatile unsigned xdos_p0_dma_total_us = 0;
volatile unsigned xdos_p0_dma_max_us = 0;
volatile unsigned xdos_p0_dirty_pixels = 0;
volatile unsigned xdos_p0_cpu_flushes = 0;
}
static volatile unsigned s_xdos_dma_start_us = 0;
static volatile bool s_xdos_dma_pending = false;'''%(rows,threshold),1)
    mod=mod.replace('unsigned nBufSizePixels = nWidth * nHeight/10;',
                    '''// Partial refresh: 64 rows default; benchmark can sweep 32/64/96.
\tunsigned nBufSizePixels = nWidth * XDOS_P0_BUFFER_ROWS;''',1)
    mod=mod.replace('if (nTicks - m_nLastUpdate >= 5*CLOCKHZ/1000)',
                    '''// Adaptive LVGL timer: do not call lv_timer_handler at loop speed.
\tstatic unsigned s_next_wait_ms = 5;
\tif (nTicks - m_nLastUpdate >= s_next_wait_ms * (CLOCKHZ/1000))''',1)
    mod=mod.replace('lv_timer_handler ();',
                    '''unsigned wait_ms = lv_timer_handler ();
\t\tif (wait_ms < 5) wait_ms = 5;
\t\tif (wait_ms > 20) wait_ms = 20;
\t\ts_next_wait_ms = wait_ms;''',1)
    hook='s_pThis->m_pDisplay->SetArea (Area, pBuffer, DisplayFlushComplete, pDisplay);'
    replacement='''// LVGL's area is already dirty-clipped; do not repaint the full screen.
\tconst unsigned w = (unsigned) (pArea->x2 - pArea->x1 + 1);
\tconst unsigned h = (unsigned) (pArea->y2 - pArea->y1 + 1);
\tconst unsigned pixels = w * h;
\txdos_p0_dirty_pixels += pixels;
\t// For very small updates DMA setup/IRQ costs more than short CPU copies.
\tif (s_pThis->m_pScreen && s_pThis->m_pDisplay->GetDepth () == 16 &&
\t    pixels < XDOS_P0_MIN_DMA_PIXELS)
\t{
\t\tCBcmFrameBuffer *fb=s_pThis->m_pScreen->GetFrameBuffer ();
\t\tif (fb && fb->GetBuffer ())
\t\t{
\t\t\txdos_flush_rgb565 ((void *)(uintptr)fb->GetBuffer (), fb->GetPitch (),
\t\t\t    16, fb->GetWidth (), fb->GetHeight (), pArea->x1, pArea->y1,
\t\t\t    pArea->x2, pArea->y2, (const u16 *)pBuffer);
\t\t\t++xdos_p0_cpu_flushes;
\t\t\tlv_display_flush_ready (pDisplay);
\t\t\treturn;
\t\t}
\t}
\t// With SCREEN_DMA_BURST_LENGTH enabled, Circle's SetArea() starts a
\t// 2D DMA and only invokes DisplayFlushComplete after the IRQ completes.
\t// LVGL retains this draw buffer until lv_display_flush_ready is called.
\tif (s_pThis->m_pScreen && s_pThis->m_pDisplay->GetDepth () == 16)
\t{
\t\ts_xdos_dma_start_us = CTimer::GetClockTicks ();
\t\ts_xdos_dma_pending = true;
\t\t++xdos_p0_dma_submitted;
\t}
\t'''+hook
    mod=mod.replace(hook,replacement,1)
    old='''void CLVGL::DisplayFlushComplete (void *pParam)
{
\tlv_display_t *pDisplay = (lv_display_t *) pParam;'''
    new='''void CLVGL::DisplayFlushComplete (void *pParam)
{
\tif (s_xdos_dma_pending)
\t{
\t\tunsigned elapsed=CTimer::GetClockTicks () - s_xdos_dma_start_us;
\t\ts_xdos_dma_pending=false;
\t\txdos_p0_dma_total_us+=elapsed;
\t\tif (elapsed>xdos_p0_dma_max_us) xdos_p0_dma_max_us=elapsed;
\t\t++xdos_p0_dma_completed;
\t}
\tlv_display_t *pDisplay = (lv_display_t *) pParam;'''
    if mod.count(old)!=1:raise SystemExit('Circle DisplayFlushComplete mismatch; unchanged')
    mod=mod.replace(old,new,1)
    needle='LV_DISP_RENDER_MODE_PARTIAL);'
    if mod.count(needle)!=1:raise SystemExit('LVGL render-mode API mismatch; unchanged')
    mod=mod.replace(needle,needle+'\n\tlv_timer_t *xdos_refresh=lv_display_get_refr_timer (display);\n\tif (xdos_refresh) lv_timer_set_period (xdos_refresh,20);',1)
if '// XDOS_P0_DMA_WFI_V2' not in old_fb:
    needle='''\twhile (AtomicCompareExchange (&m_nDMAInUse, 0, 1))
\t{
\t\t// TODO: Yield with NO_BUSY_WAIT, when on core 0 in TASK_LEVEL
\t}'''
    if old_fb.count(needle)!=1:
        raise SystemExit('Circle framebuffer DMA guard mismatch; unchanged')
    fb_mod=old_fb.replace('#include <circle/atomic.h>',
                  '#include <circle/atomic.h>\n#include <circle/synchronize.h>\n#include <circle/sched/scheduler.h>',1)
    fb_mod=fb_mod.replace(needle,
                  '''\t// XDOS_P0_DMA_WFI_V2: task-context only; interrupts must be enabled.
\t// The DMA completion IRQ releases m_nDMAInUse; do not burn CPU cycles.
\twhile (AtomicCompareExchange (&m_nDMAInUse, 0, 1))
\t{
\t\tif (CScheduler::IsActive ()) CScheduler::Get ()->MsSleep (1);
\t\telse WaitForInterrupt ();
\t}''',1)
else:fb_mod=old_fb
if mod!=old_lv:
    backup=lv.with_name('lvgl.cpp.xdos-p0-pre')
    if not backup.exists():shutil.copy2(lv,backup)
    lv.write_text(mod)
    shutil.copy2(source,lv.with_name('xdos_flush_fast.h'))
if fb_mod!=old_fb:
    backup=fb.with_name('bcmframebuffer.cpp.xdos-p0-pre')
    if not backup.exists():shutil.copy2(fb,backup)
    fb.write_text(fb_mod)
print(f'XDOS P0 patch ready: buffer_rows={rows}, dma_min_pixels={threshold}; full-screen LVGL dirty via Circle IRQ DMA')
