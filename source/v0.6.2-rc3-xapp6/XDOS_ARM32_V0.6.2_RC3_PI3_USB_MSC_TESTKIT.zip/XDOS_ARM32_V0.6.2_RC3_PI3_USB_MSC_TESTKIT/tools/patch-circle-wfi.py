#!/usr/bin/env python3
"""Idempotent, fail-closed WFI/idle-stat patch for Circle's cooperative scheduler.
Makes a timestamped .xdos-original backup on first patch. Requires irq/timer init.
"""
from pathlib import Path
import sys,shutil
circle=Path(sys.argv[1])
p=circle/'lib/sched/scheduler.cpp'
s=p.read_text()
marker='// XDOS_SDK_WFI_V1'
if marker in s:
 print('WFI patch already installed');sys.exit(0)
anchor='#include <circle/sched/scheduler.h>'
if s.count(anchor)!=1:
 raise SystemExit('Circle scheduler header mismatch; no changes')
if '#include <circle/synchronize.h>' not in s:
 s=s.replace(anchor,anchor+'\n#include <circle/synchronize.h>',1)
original="""\twhile ((m_nCurrent = GetNextTask ()) == MAX_TASKS)\t// no task is ready
\t{
\t\tassert (m_nTasks > 0);
\t}"""
# Some users already applied a simple WFI patch; replace it with accounting.
previous_wfi=original.replace("\t\tassert (m_nTasks > 0);",
                              "\t\tassert (m_nTasks > 0);\n\t\tWaitForInterrupt ();")
if original not in s and previous_wfi not in s:
 raise SystemExit('Circle Scheduler::Yield layout mismatch; no changes')
replacement="""\twhile ((m_nCurrent = GetNextTask ()) == MAX_TASKS)\t// no task is ready
\t{
\t\tassert (m_nTasks > 0);
\t\tconst unsigned before=CTimer::GetClockTicks ();
\t\tWaitForInterrupt ();  // XDOS_SDK_WFI_V1
\t\tconst unsigned after=CTimer::GetClockTicks ();
\t\txdos_wfi_microseconds += after - before;
\t\t++xdos_wfi_entries;
\t}"""
s=s.replace(original if original in s else previous_wfi,replacement,1)
needle='static const char FromScheduler[] = "sched";'
if needle not in s:raise SystemExit('Circle scheduler marker missing; no changes')
s=s.replace(needle,"""extern "C" {
volatile unsigned xdos_wfi_entries=0;
volatile unsigned xdos_wfi_microseconds=0;
}
"""+needle,1)
shutil.copy2(p,p.with_name('scheduler.cpp.xdos-original')) if not p.with_name('scheduler.cpp.xdos-original').exists() else None
p.write_text(s)
print('Applied WFI & counters to',p)
