#!/usr/bin/env python3
"""Fail a Circle Pi3 kernel build if XAPP slot lies outside executable .text."""
import subprocess,sys
if len(sys.argv)!=2: raise SystemExit("usage: check-exec-section.py kernel8-32.elf")
out=subprocess.check_output(["arm-none-eabi-nm","-n",sys.argv[1]],text=True)
syms={}
for line in out.splitlines():
    fields=line.split()
    if len(fields)==3:
        address,kind,name=fields
        if name in ("xdos_xapp_exec_slot","xdos_xapp_exec_slot_end","_etext"):
            syms[name]=(int(address,16),kind)
for key in ("xdos_xapp_exec_slot","xdos_xapp_exec_slot_end","_etext"):
    if key not in syms: raise SystemExit(f"Missing symbol: {key}")
start=syms["xdos_xapp_exec_slot"][0]
end=syms["xdos_xapp_exec_slot_end"][0]
etext=syms["_etext"][0]
if start & 63 or end-start!=65536 or not (start<end<=etext):
    raise SystemExit(f"XAPP slot invalid: 0x{start:X}..0x{end:X} _etext=0x{etext:X}")
print(f"XAPP EXEC SLOT OK: 0x{start:X}..0x{end:X} inside .text (_etext=0x{etext:X})")
