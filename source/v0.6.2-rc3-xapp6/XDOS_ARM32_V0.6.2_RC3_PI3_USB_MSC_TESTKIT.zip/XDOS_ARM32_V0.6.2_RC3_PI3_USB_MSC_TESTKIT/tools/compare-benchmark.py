#!/usr/bin/env python3
"""Compare the last two complete XD OS LVGL benchmark sessions from FAT32 CSV.
The four scenes are fixed; higher FPS is better, lower Render/Flush time is better.
Usage: python3 compare-benchmark.py BENCH.CSV
"""
import csv,sys
from pathlib import Path
SCENES=['TEXT_24','MOVE_36','ALPHA_24','FULL_REDRAW']
if len(sys.argv)!=2: raise SystemExit('Usage: compare-benchmark.py BENCH.CSV')
rows=list(csv.DictReader(Path(sys.argv[1]).open(newline='',encoding='utf-8-sig')))
all_sessions=[]
for offset in range(0,len(rows)-3):
    group=rows[offset:offset+4]
    if [r['scene'] for r in group]==SCENES:
        all_sessions.append(group)
if not all_sessions:
    raise SystemExit('No complete set of four benchmark scenes in CSV.')
for i,g in enumerate(all_sessions,1):
    print(f'RUN {i}: {g[0]["version"]} on {g[0]["board"]} / {g[0]["resolution"]}')
    for r in g:
        print('  %-12s %5.1f FPS  render %6dus  flush %6dus frames %4s' % (
            r['scene'],int(r['fps_x10'])/10,int(r['render_avg_us']),
            int(r['flush_avg_us']),r['frames']))
if len(all_sessions)>=2:
    before,after=all_sessions[-2:]
    print('\nLAST TWO RUNS FPS CHANGE:')
    for a,b in zip(before,after):
        old=float(a['fps_x10']);new=float(b['fps_x10'])
        change=(new-old)*100/old if old else 0
        print(f'{a["scene"]:<12} {change:+.1f}%  ({old/10:.1f} -> {new/10:.1f} FPS)')
