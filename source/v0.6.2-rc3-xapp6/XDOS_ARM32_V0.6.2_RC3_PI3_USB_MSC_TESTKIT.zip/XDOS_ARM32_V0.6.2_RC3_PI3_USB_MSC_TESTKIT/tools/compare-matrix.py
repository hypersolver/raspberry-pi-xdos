#!/usr/bin/env python3
"""Compare per-run CSV snapshots from the RC2 four-scene benchmark.
Usage: python3 tools/compare-matrix.py RESULTS_DIR [RESULTS_DIR...]
Only complete benchmark groups are included; no invented metrics.
"""
import csv,sys,pathlib
SCENES=['TEXT_24','MOVE_36','ALPHA_24','FULL_REDRAW']

def load(path):
    with path.open(encoding='utf-8-sig',newline='') as fp: return list(csv.DictReader(fp))

def last_complete(rows):
    # Supports append-only CSVs: choose last full ordered block.
    for n in range(len(rows)-4,-1,-1):
        group=rows[n:n+4]
        if [r.get('scene') for r in group]==SCENES: return group
    return None

def parse_dir(folder):
    p=pathlib.Path(folder)
    if not (p/'BENCH.CSV').exists(): raise ValueError(f'{p}: missing BENCH.CSV')
    bench=last_complete(load(p/'BENCH.CSV'))
    if bench is None: raise ValueError(f'{p}: no complete four-scene BENCH.CSV set')
    dma=last_complete(load(p/'P0DMA.CSV')) if (p/'P0DMA.CSV').exists() else None
    info={}
    if (p/'RUN_INFO.txt').exists():
        for line in (p/'RUN_INFO.txt').read_text().splitlines():
            if '=' in line:
                k,v=line.split('=',1);info[k]=v
    return p,info,bench,dma

def main(args):
    if not args:
        print(__doc__.strip());return 2
    parsed=[]
    for arg in args:
        parsed.append(parse_dir(arg))
    print('| Variant | Scene | FPS | Render avg (ms) | Flush callback (ms) | DMA avg (ms) | Dirty % |')
    print('|---|---|---:|---:|---:|---:|---:|')
    for p,info,bench,dma in parsed:
        variant=info.get('variant',p.name)
        for i,row in enumerate(bench):
            dr=dma[i] if dma else None
            fps=int(row['fps_x10'])/10
            render=int(row['render_avg_us'])/1000
            flush=int(row['flush_avg_us'])/1000
            dma_avg=f'{int(dr["dma_avg_us"])/1000:.3f}' if dr else 'N/A'
            dirty=f'{int(dr["dirty_percent_x100"])/100:.2f}' if dr else 'N/A'
            print(f'| {variant} | {row["scene"]} | {fps:.1f} | {render:.3f} | {flush:.3f} | {dma_avg} | {dirty} |')
    if len(parsed)>=2:
        first=parsed[0][2];last=parsed[-1][2]
        print('\nFPS change, first vs last:')
        for a,b in zip(first,last):
            x=int(a['fps_x10']);y=int(b['fps_x10'])
            delta=f'{(y/x-1)*100:+.1f}%' if x else 'N/A'
            print(f'- {a["scene"]}: {x/10:.1f} -> {y/10:.1f} ({delta})')
    return 0
if __name__=='__main__':
    try:sys.exit(main(sys.argv[1:]))
    except (ValueError,KeyError,OSError) as e:
        print('ERROR:',e,file=sys.stderr);sys.exit(2)
