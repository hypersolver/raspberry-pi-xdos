#!/usr/bin/env python3
"""Pi3-only, idempotent Circle LVGL 9 performance patch.
Creates .xdos-original backup; rejects unexpected upstream layout instead of
silently producing a broken screen driver. Only for CScreenDevice / RGB565.
"""
from pathlib import Path
import shutil,sys
if len(sys.argv)!=2: raise SystemExit('usage: patch-circle-lvgl.py /path/to/circle')
circle=Path(sys.argv[1]);p=circle/'addon/lvgl/lvgl.cpp'
source=Path(__file__).resolve().parents[1]/'source/95-xdos-arm32-dualnet/lvgl_flush_fast.h'
assert p.exists() and source.exists()
s=p.read_text()
mark='// XDOS_PI3_RGB565_FAST_V1'
if mark in s:
    print('Circle LVGL fast flush already applied')
    sys.exit(0)
needle='#include <lvgl/lvgl.h>'
if s.count(needle)!=1: raise SystemExit('Circle LVGL header layout differs: no changes')
if s.count('unsigned nBufSizePixels = nWidth * nHeight/10;')!=1:
    raise SystemExit('Circle LVGL buffer layout differs: no changes')
marker='s_pThis->m_pDisplay->SetArea (Area, pBuffer, DisplayFlushComplete, pDisplay);'
if s.count(marker)!=1: raise SystemExit('Circle LVGL flush layout differs: no changes')
s=s.replace(needle,needle+'\n#include "xdos_flush_fast.h"',1)
s=s.replace('unsigned nBufSizePixels = nWidth * nHeight/10;',
'''// XDOS_PI3_RGB565_FAST_V1: 32-row double partial buffers instead of 10% of height.
\tunsigned nBufSizePixels = nWidth * 32;''',1)
# Set LVGL's actual display refresh timer to the 20ms benchmark target.
if s.count('LV_DISP_RENDER_MODE_PARTIAL);') != 1:
    raise SystemExit('Circle LVGL render-mode API differs: no changes')
s=s.replace('LV_DISP_RENDER_MODE_PARTIAL);',
    'LV_DISP_RENDER_MODE_PARTIAL);\n\tlv_timer_t *refresh = lv_display_get_refr_timer (display);\n\tif (refresh) lv_timer_set_period (refresh, 20); // XDOS_PI3_20MS_REFRESH', 1)

s=s.replace(marker,'''
\t// Direct CPU RGB565 row copy for Pi3 HDMI. LVGL buffer data is already
\t// rendered; this path avoids display SetArea's pixel-at-a-time overhead.
\t// Keep Circle's native display path for SPI/I2C and other color depths.
\tif (s_pThis->m_pScreen != 0 && s_pThis->m_pDisplay->GetDepth () == 16)
\t{
\t\tCBcmFrameBuffer *fb = s_pThis->m_pScreen->GetFrameBuffer ();
\t\tif (fb != 0 && fb->GetBuffer ())
\t\t{
\t\t\txdos_flush_rgb565 ((void *)(uintptr) fb->GetBuffer (),
\t\t\t\tfb->GetPitch (), fb->GetDepth (), fb->GetWidth (),
\t\t\t\tfb->GetHeight (), pArea->x1, pArea->y1, pArea->x2,
\t\t\t\tpArea->y2, (const u16 *)pBuffer);
\t\t\tlv_display_flush_ready (pDisplay);
\t\t\treturn;
\t\t}
\t}
\ts_pThis->m_pDisplay->SetArea (Area, pBuffer, DisplayFlushComplete, pDisplay);''',1)
backup=p.with_name('lvgl.cpp.xdos-original')
if not backup.exists():shutil.copy2(p,backup)
shutil.copy2(source,p.with_name('xdos_flush_fast.h'))
p.write_text(s)
print('Pi3 LVGL patch: RGB565 direct flush and 32-row dual buffers',p)
