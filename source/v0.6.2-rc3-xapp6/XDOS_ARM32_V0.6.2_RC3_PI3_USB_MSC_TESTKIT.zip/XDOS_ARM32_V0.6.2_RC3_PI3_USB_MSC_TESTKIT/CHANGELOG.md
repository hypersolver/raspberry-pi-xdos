# CHANGELOG

## 0.6.2-RC3 — USB Mass Storage Test Kit
- See CHANGELOG_USB_MSC_RC3.md
- Based on 0.6.2-RC2 P0 GUI test kit; unchanged original P0 render/Benchmark settings.

## 0.6.2-RC2
- LVGL Dirty Area, DMA Async Flush, Buffer tuning, WFI/Idle, Benchmark.
