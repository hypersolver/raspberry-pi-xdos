/* ARM32 ABI v1 extension: benchmark callback at offset 20, original demo at 16. */
.syntax unified
.arm
.section .xapp_header,"a",%progbits
.balign 4
.global xapp_image_start
xapp_image_start:
    .ascii "XDAP"
    .word 1
    .word 32
    .word xapp_image_end-xapp_image_start
    .word xapp_entry-xapp_image_start
    .word 0
    .word 0
    .word 0
.section .text,"ax",%progbits
.balign 4
.global xapp_entry
.type xapp_entry,%function
xapp_entry:
    push {r4,lr}
    cmp r0,#0
    beq invalid
    ldr r1,[r0,#0]            @ api version
    cmp r1,#1
    bne invalid
    ldr r1,[r0,#4]            @ struct_bytes
    cmp r1,#24                @ new benchmark service available
    blo invalid
    mov r4,r0
    ldr r0,[r4,#8]           @ context
    ldr r3,[r4,#20]          @ show_lvgl_benchmark
    cmp r3,#0
    beq invalid
    blx r3
    pop {r4,pc}
invalid:
    mvn r0,#0
    pop {r4,pc}
.balign 4
.global xapp_image_end
xapp_image_end:
