# XD OS USB 隨身碟整合測試（V0.6.2-RC3）

## 支援
- Raspberry Pi 3B / 3B+ ARM32；RPi 4 是 Ubuntu 編譯主機，不是本輪執行目標。
- USB Mass Storage Bulk-Only Transport (BOT)／SCSI，USB Host 由 Circle 提供。
- 第一支裝置採 `umsd1` → `USB:`；支援 FAT16/FAT32、512-byte logical sector。
- `SD:` 保持為 MicroSD，不修改系統啟動映像與 XAPP 讀取路徑。
- **目前不支援** exFAT、NTFS、UASP-only、4K logical sector 或多支同時掛載。

## 編譯（RPi4 Ubuntu）
```bash
cd ~/xdos-build
unzip -o XDOS_ARM32_V0.6.2_RC3_PI3_USB_MSC_TESTKIT.zip
cd XDOS_ARM32_V0.6.2_RC3_PI3_USB_MSC_TESTKIT
bash tests/run-host-tests.sh
bash tests/run-lvgl-syntax-check.sh
bash build-on-rpi4.sh
ls -l output/xdos32-v062-rc3-pi3.img
```

## 開機與指令
LVGL 首頁新增 **USB LIST / USB EJECT** 按鈕；接上 USB 鍵盤可直接在首頁輸入 Terminal 指令（文字會顯示在頁面下方）。
```
usb status
usb ls
usb cat TEST.TXT
usb write XDOSTEST.TXT hello-from-XDOS
usb cat XDOSTEST.TXT
usb eject
```
**注意 `usb write` 會覆蓋同名檔案。** 不要拿有重要資料的 USB 隨身碟直接進行寫入測試。

第一次測試請用空白的 FAT32 USB 隨身碟。USB 插入後需待 Circle USB Host 列舉及後台 FatFs 掛載成功，Terminal 輸入 `usb status` 看到 `USB: FAT MOUNTED (USB:/)`。

`usb eject` 先完成檔案 close / sync，再邏輯卸載。看到 `USB: SAFE TO REMOVE` 才拔掉；重新插入會自動掛載；如需在原裝置上重新掛載，可輸入 `usb mount`。

## 測試
1. RPi3B HDMI GUI 能啟動，USB 隨身碟在桌面出現後插入。
2. `usb status` → FAT MOUNTED；`usb ls` 可列出根目錄。
3. `usb cat` 讀取事先放入的短文字。
4. `usb write XDOSTEST.TXT hello-from-XDOS` → 重新 `usb cat` 確認。
5. `usb eject` 後在 Windows 讀取該檔內容。
6. 重新插入測試熱插拔；再次測試 LVGL Benchmark 與鍵盤／滑鼠。

## 重要限制與已知風險
- USB 裝置的 Circle Host 初始化仍在桌面可見之前；此版只把 **USB Volume 掛載** 延後。
- FatFs 路徑驗證與主機單元測試通過，不代表整體 Circle Link 或 USB 實測通過。
- Linux/Windows 常用的 exFAT 不能使用；請用 FAT32 格式的空碟測試。
- 不要在寫入時拔除；USB 實體拔除無法保證資料完整性。

## Windows 傳檔 / 測試矩陣
在 RPi 4 編譯三種 Buffer 變體：
```bash
bash build-test-matrix-on-rpi4.sh --quick
```
在 Windows 將 ZIP 傳回、部署與收集結果：
```powershell
.\Get-XDOS-RC3.ps1 -Variant r64-d512
.\Deploy-XDOS-RC3.ps1 -Drive E: -Variant r64-d512
.\Collect-XDOS-RC3.ps1 -Drive E: -Variant r64-d512
```
`Get`、`Deploy`、`Collect` 腳本位於 `windows/` 資料夾。
