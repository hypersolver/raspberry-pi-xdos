# XD OS ARM32 V0.6.2-RC3 — USB Mass Storage (Pi 3B / 3B+)

Based on V0.6.2-RC2 P0 GUI Test Kit. Prior source/SDK/Benchmark unchanged except items below.

- Circle USB Bulk-Only Mass Storage (umsd1) integrated through FatFs USB: (no new USB protocol driver).
- USB FAT16/FAT32 logical mount/unmount after desktop through single storage worker.
- Terminal: `usb status`, `usb ls`, `usb cat FILE.TXT`, `usb write FILE.TXT text`, `usb eject`, `usb mount`.
- Safe root-only filename validation, no traversal, bounded text writes, f_sync + f_close.
- Eject means **logical unmount**, does not power-off or physically disconnect USB device.
- USB status on LVGL home screen.
- Does not alter SD:/, XAPP Loader, LVGL benchmark, DMA patch or Arduino runtime.

**Limits**: First drive only USB:; stock Circle is USB MSC BOT / SCSI with 512-byte logical sectors. exFAT/NTFS are not enabled. The Circle USB host initialization may still be synchronous before the desktop; only USB volume mounting is deferred, and synchronous I/O can still briefly pause a cooperative scheduler. USB hot-remove during active writes can lose data. Not yet complete Circle link or RPi 3 hardware validated.
