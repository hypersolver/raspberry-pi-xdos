[Application]
Name=LVGL Benchmark
Exec=SD:/XDOS/APPS/LVGLBENCH.XAPP
ABI=1
Arch=armv7-a32
