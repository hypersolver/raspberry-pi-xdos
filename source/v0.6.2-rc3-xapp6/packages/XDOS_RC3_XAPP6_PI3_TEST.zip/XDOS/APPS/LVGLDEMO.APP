[Application]
Name=LVGL Widgets
Exec=SD:/XDOS/APPS/LVGLDEMO.XAPP
ABI=1
Arch=armv7-a32
