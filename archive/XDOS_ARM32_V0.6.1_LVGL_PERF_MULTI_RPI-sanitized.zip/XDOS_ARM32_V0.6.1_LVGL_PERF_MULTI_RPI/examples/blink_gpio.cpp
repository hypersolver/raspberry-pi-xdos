#include "Arduino.h"
// Example only: replace default xdos_arduino/sketch.cpp with this code
// after verifying wiring. BCM GPIO17 = physical header pin 11 on 40-pin Pi.
constexpr uint8_t LED_PIN=17;
void setup() { Serial.begin(115200); pinMode(LED_PIN,OUTPUT); }
void loop() {
    digitalWrite(LED_PIN,HIGH); delay(500);
    digitalWrite(LED_PIN,LOW);  delay(500);
}
