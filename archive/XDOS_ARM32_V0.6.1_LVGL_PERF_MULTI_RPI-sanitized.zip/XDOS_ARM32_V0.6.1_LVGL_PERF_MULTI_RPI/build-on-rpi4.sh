#!/usr/bin/env bash
# Existing Pi4 Ubuntu cross-build machine; outputs Pi3 ARM32 image by default.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ $# -gt 0 ]]; then exec "$ROOT/build-multi-rpi.sh" "$@"; fi
exec "$ROOT/build-multi-rpi.sh" 3
