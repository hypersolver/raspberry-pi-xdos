# XDOS v0.6 candidate

- Based on original V0.5.3 desktop-first sources, without replacing original files in the user's Library.
- Added `XDOS_GUI=lvgl|legacy` build switch.
- Integrated Circle LVGL v9-style wrapper in partial framebuffer mode (RGB565), log/status Arduino view.
- Added small Arduino API subset via Circle GPIO, timer, UART and cooperative Sketch task.
- Separated Raspberry Pi 1/2/3/4 builds, images and ARM architecture selection; Wi-Fi conditional for older targets.
- Pi1-compatible ARMv6 asm backend and low-resolution defaults.
- Preserved pre-existing Network HTTP worker as a backend; legacy browser UI is not ported to LVGL yet.
- Static validation performed; hardware functionality NOT yet verified.

## v0.6.1 LVGL performance pass
- Refresh LVGL labels only when their underlying revision changes.
- Cap terminal viewport to last visible lines with a fixed 1 KiB scratch buffer.
- Throttle Arduino loop display to 500 ms and use clock-based 33 ms UI/250 ms network polling.
- Preserve legacy GUI, Circle 10% x2 draw buffers, boot splash and existing Arduino source.
- Integration candidate, not board-verified.
