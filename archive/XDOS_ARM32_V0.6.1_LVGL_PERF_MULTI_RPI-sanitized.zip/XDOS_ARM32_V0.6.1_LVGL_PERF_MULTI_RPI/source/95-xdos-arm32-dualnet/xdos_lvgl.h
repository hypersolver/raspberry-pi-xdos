#ifndef XDOS_LVGL_UI_H
#define XDOS_LVGL_UI_H
#include <lvgl/lvgl.h>
class Desktop;
// Main UI task owns LVGL. Network and Arduino worker tasks only update model.
class XDOSLVGL {
public:
    XDOSLVGL();
    void Initialize(Desktop *desktop);
    void Refresh(unsigned nowUs);
    void OnKey(char ch); // existing Desktop key handling remains independent
    unsigned TextUpdateCount() const { return textUpdateCount_; }
private:
    Desktop *desktop_;
    lv_obj_t *title_, *status_, *term_, *sketch_;
    unsigned lastStatusRevision_, lastTerminalRevision_, lastLoops_;
    unsigned lastLoopSampleUs_, consoleLines_, textUpdateCount_;
    char terminalView_[1024];  // bounded terminal viewport; no dynamic allocation
};
#endif
