#include "xdos_lvgl.h"
#include "xdos_lvgl_tail.h"
#include "desktop.h"
#include "xdos_arduino/xdos_arduino_runtime.h"
#include <stdio.h>

namespace {
// A rapidly advancing Arduino loop counter is not a useful 100 Hz GUI update.
static const unsigned LOOP_SAMPLE_US = 500000U;
}

XDOSLVGL::XDOSLVGL()
: desktop_(0), title_(0), status_(0), term_(0), sketch_(0),
  lastStatusRevision_(~0U), lastTerminalRevision_(~0U),
  lastLoops_(~0U), lastLoopSampleUs_(0), consoleLines_(16),
  textUpdateCount_(0)
{
    terminalView_[0] = '\0';
}

void XDOSLVGL::Initialize(Desktop *desktop)
{
    desktop_ = desktop;
    lv_obj_t *screen = lv_screen_active();
    lv_obj_set_style_bg_color(screen, lv_color_hex(0x101D2D), 0);
    lv_obj_set_style_text_color(screen, lv_color_hex(0xD5F1DC), 0);
    lv_obj_t *column = lv_obj_create(screen);
    lv_obj_set_size(column, lv_pct(96), lv_pct(94));
    lv_obj_center(column);
    lv_obj_set_flex_flow(column, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(column, 10, 0);
    lv_obj_set_style_pad_row(column, 6, 0);
    lv_obj_set_style_bg_color(column, lv_color_hex(0x15283B), 0);
    lv_obj_set_style_border_color(column, lv_color_hex(0x426882), 0);
    lv_obj_set_scrollbar_mode(column, LV_SCROLLBAR_MODE_OFF);

    title_ = lv_label_create(column);
    lv_label_set_text(title_, "XDOS 0.6.1   |   BARE-METAL / LVGL / ARDUINO");
    lv_obj_set_style_text_color(title_, lv_color_hex(0x72E4AC), 0);

    status_ = lv_label_create(column);
    lv_obj_set_width(status_, lv_pct(100));
    lv_label_set_text(status_, "NET: STARTS IN DESKTOP");

    sketch_ = lv_label_create(column);
    lv_label_set_text(sketch_, "Arduino: starting");

    term_ = lv_label_create(column);
    lv_obj_set_width(term_, lv_pct(100));
    lv_label_set_long_mode(term_, LV_LABEL_LONG_WRAP);
    // Only show visible terminal lines: avoids invisible layout/render work.
    lv_display_t *display = lv_display_get_default();
    const unsigned h = display ? (unsigned)lv_display_get_vertical_resolution(display) : 480U;
    consoleLines_ = h > 700U ? 25U : h > 550U ? 17U : 12U;
    lv_label_set_text(term_, "Terminal ready");
    Refresh(0);
}

void XDOSLVGL::OnKey(char ch) { (void)ch; }

void XDOSLVGL::Refresh(unsigned nowUs)
{
    if (!desktop_ || !term_) return;
    // Revision counters make the idle UI path O(1), instead of hashing text.
    unsigned revision = desktop_->NetworkRevision();
    if (revision != lastStatusRevision_) {
        lv_label_set_text(status_, desktop_->NetworkStatus());
        ++textUpdateCount_;
        lastStatusRevision_ = revision;
    }
    revision = desktop_->TerminalRevision();
    if (revision != lastTerminalRevision_) {
        xdos_copy_terminal_tail(desktop_->TerminalText(), terminalView_,
                                sizeof terminalView_, consoleLines_);
        lv_label_set_text(term_, terminalView_);
        ++textUpdateCount_;
        lastTerminalRevision_ = revision;
    }
    if (lastLoops_ == ~0U || (unsigned)(nowUs - lastLoopSampleUs_) >= LOOP_SAMPLE_US) {
        const unsigned count = xdos_arduino_loop_count();
        if (count != lastLoops_) {
            char line[80];
            snprintf(line, sizeof line, "Arduino: running  |  loop count: %u", count);
            lv_label_set_text(sketch_, line);
            ++textUpdateCount_;
            lastLoops_ = count;
        }
        lastLoopSampleUs_ = nowUs;
    }
}
