#ifndef XDOS_ARDUINO_H
#define XDOS_ARDUINO_H
// XDOS Arduino subset: BCM GPIO numbering (not physical header pin numbering).
// Bare-metal Circle, AArch32. No AVR register emulation, ADC or full Arduino libraries.
#include <stdint.h>
#include <stddef.h>
#ifndef HIGH
#define HIGH 1
#endif
#ifndef LOW
#define LOW 0
#endif
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define INPUT_PULLDOWN 3

#ifdef __cplusplus
extern "C" {
#endif
void pinMode(uint8_t pin, uint8_t mode);
void digitalWrite(uint8_t pin, uint8_t value);
int digitalRead(uint8_t pin);
unsigned long millis(void);
unsigned long micros(void);
void delay(unsigned long milliseconds);
void delayMicroseconds(unsigned int microseconds);
void yield(void);
int xdos_arduino_error(void);
#ifdef __cplusplus
}

class XDOSHardwareSerial
{
public:
    void begin(unsigned long baud); // already initialized by Circle kernel
    void print(const char *s);
    void print(long n);
    void println(const char *s);
    void println(long n);
    void println(void);
};
extern XDOSHardwareSerial Serial;

// Link exactly one sketch.cpp file that implements both functions.
void setup(void);
void loop(void);
#endif
#endif
