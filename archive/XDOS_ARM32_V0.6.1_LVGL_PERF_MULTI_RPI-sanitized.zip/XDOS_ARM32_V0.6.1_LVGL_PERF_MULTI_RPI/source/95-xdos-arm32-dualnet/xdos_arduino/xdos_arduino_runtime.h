#ifndef XDOS_ARDUINO_RUNTIME_H
#define XDOS_ARDUINO_RUNTIME_H
class CSerialDevice;
void xdos_arduino_attach_serial(CSerialDevice *dev);
void xdos_arduino_mark_loop(void);
unsigned xdos_arduino_loop_count(void);
#endif
