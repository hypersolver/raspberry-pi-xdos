#include "Arduino.h"
#include "xdos_arduino_runtime.h"
#include <circle/gpiopin.h>
#include <circle/timer.h>
#include <circle/serial.h>
#include <circle/sched/scheduler.h>
#include <circle/new.h>
#include <string.h>

namespace {
static CSerialDevice *g_uart = 0;
static CGPIOPin *g_pin[54] = {};
static int g_error = 0; // 0=ok, 1=invalid pin, 2=invalid mode, 3=out of memory
static volatile unsigned g_loops = 0;

static CGPIOPin *get_pin(uint8_t pin) {
    if (pin >= 54) { g_error = 1; return 0; }
    if (!g_pin[pin]) {
        g_pin[pin] = new CGPIOPin(pin, GPIOModeInput);
        if (!g_pin[pin]) g_error = 3;
    }
    return g_pin[pin];
}
static void print_num(long n) {
    char tmp[24]; unsigned i=0;
    const bool neg=n<0;
    unsigned long v=neg ? (unsigned long)(-(n+1))+1UL : (unsigned long)n;
    do {tmp[i++]=(char)('0'+v%10UL); v/=10UL;} while(v && i<sizeof(tmp)-2);
    if(neg) tmp[i++]='-';
    char out[24]; unsigned j=0;
    while (i) out[j++]=tmp[--i];
    out[j]=0;
    if(g_uart) g_uart->Write(out,j);
}
}

void xdos_arduino_attach_serial(CSerialDevice *dev) { g_uart=dev; }
void xdos_arduino_mark_loop(void) { ++g_loops; }
unsigned xdos_arduino_loop_count(void) { return g_loops; }
int xdos_arduino_error(void) { return g_error; }

extern "C" void pinMode(uint8_t pin, uint8_t mode) {
    CGPIOPin *p=get_pin(pin); if(!p) return;
    switch (mode) {
    case INPUT: p->SetMode(GPIOModeInput); break;
    case OUTPUT: p->SetMode(GPIOModeOutput); break;
    case INPUT_PULLUP: p->SetMode(GPIOModeInputPullUp); break;
    case INPUT_PULLDOWN: p->SetMode(GPIOModeInputPullDown); break;
    default: g_error=2; break;
    }
}
extern "C" void digitalWrite(uint8_t pin, uint8_t value) {
    CGPIOPin *p=get_pin(pin); if(p) p->Write(value ? HIGH : LOW);
}
extern "C" int digitalRead(uint8_t pin) {
    CGPIOPin *p=get_pin(pin); return p ? (int)p->Read() : LOW;
}
extern "C" unsigned long millis(void) {
    return (unsigned long)(CTimer::GetClockTicks64()/1000ULL);
}
extern "C" unsigned long micros(void) {
    return (unsigned long)CTimer::GetClockTicks64();
}
extern "C" void delay(unsigned long ms) {
    if (CScheduler::IsActive()) {
        while(ms) { unsigned n=ms>1000UL?1000U:(unsigned)ms; CScheduler::Get()->MsSleep(n); ms-=n; }
    } else {
        while(ms) { unsigned n=ms>1000UL?1000U:(unsigned)ms; CTimer::SimpleMsDelay(n); ms-=n; }
    }
}
extern "C" void delayMicroseconds(unsigned int us) { CTimer::SimpleusDelay(us); }
extern "C" void yield(void) { if(CScheduler::IsActive()) CScheduler::Get()->Yield(); }

XDOSHardwareSerial Serial;
void XDOSHardwareSerial::begin(unsigned long baud) { (void)baud; /* UART owned by Circle kernel at 115200 */ }
void XDOSHardwareSerial::print(const char *s) { if(g_uart && s) g_uart->Write(s,strlen(s)); }
void XDOSHardwareSerial::print(long n) { print_num(n); }
void XDOSHardwareSerial::println(const char *s) { print(s); println(); }
void XDOSHardwareSerial::println(long n) { print(n); println(); }
void XDOSHardwareSerial::println(void) { print("\r\n"); }
