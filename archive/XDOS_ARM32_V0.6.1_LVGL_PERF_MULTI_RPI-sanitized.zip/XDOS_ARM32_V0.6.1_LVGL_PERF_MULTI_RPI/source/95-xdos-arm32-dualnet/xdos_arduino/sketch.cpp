#include "Arduino.h"
// SAFE example: no GPIO toggled until developer deliberately installs blink_gpio.cpp.
// This Arduino sketch runs on an independent Circle cooperative task.
void setup() {
    Serial.begin(115200);
    Serial.println("[ARDUINO] XDOS sketch setup: ready");
}
void loop() {
    delay(250); // MUST yield to LVGL and network tasks
}
