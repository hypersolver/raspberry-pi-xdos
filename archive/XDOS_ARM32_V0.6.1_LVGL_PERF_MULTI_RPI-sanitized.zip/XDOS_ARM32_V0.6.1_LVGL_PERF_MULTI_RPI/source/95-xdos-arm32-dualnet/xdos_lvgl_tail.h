#ifndef XDOS_LVGL_TAIL_H
#define XDOS_LVGL_TAIL_H
#include <stddef.h>
#include <string.h>
// For the low-RAM terminal: copy the final maxLines (with a byte cap).
// No heap allocation. Returns the number of copied bytes.
static inline size_t xdos_copy_terminal_tail(const char *src, char *dst,
                                              size_t capacity, unsigned maxLines)
{
    if (!dst || !capacity) return 0;
    dst[0] = '\0';
    if (!src || !maxLines) return 0;
    size_t len = strlen(src);
    const char *begin = src;
    // Skip trailing newlines when counting the lines visible to the user.
    const char *scan = src + len;
    while (scan > begin && scan[-1] == '\n') --scan;
    unsigned breaks = 0;
    while (scan > begin) {
        --scan;
        if (*scan == '\n' && ++breaks >= maxLines) {
            begin = scan + 1;
            break;
        }
    }
    size_t bytes = (size_t)(src + len - begin);
    if (bytes >= capacity) {
        // Prefer starting at a line boundary, if possible.
        begin = src + len - (capacity - 1);
        const char *afterNewline = begin;
        while (afterNewline < src + len && *afterNewline != '\n') ++afterNewline;
        if (afterNewline + 1 < src + len) begin = afterNewline + 1;
        // If this line has no newline, keep its final bytes instead of
        // returning an empty string for a long unbroken input.
        bytes = (size_t)(src + len - begin);
    }
    memcpy(dst, begin, bytes);
    dst[bytes] = '\0';
    return bytes;
}
#endif
