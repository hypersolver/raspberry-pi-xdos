#include <cassert>
#include <cstdio>
#include <cstring>
#include <string>
#include "../source/95-xdos-arm32-dualnet/xdos_lvgl_tail.h"
int main() {
    char out[24];
    assert(xdos_copy_terminal_tail(nullptr,out,sizeof out,10)==0);
    assert(xdos_copy_terminal_tail("",out,sizeof out,10)==0);
    assert(xdos_copy_terminal_tail("one\ntwo\nthree\n",out,sizeof out,2)==10);
    assert(std::strcmp(out,"two\nthree\n")==0);
    xdos_copy_terminal_tail("abc",out,sizeof out,1);
    assert(std::strcmp(out,"abc")==0);
    xdos_copy_terminal_tail("123456789abcdefghijk",out,8,1);
    assert(std::strcmp(out,"efghijk")==0);
    xdos_copy_terminal_tail("one\ntwo\nthree\nfour\nfive\n",out,16,2);
    assert(std::strcmp(out,"four\nfive\n")==0);
    xdos_copy_terminal_tail("one\nabcdefghij\nxyz\n",out,10,2);
    assert(std::strcmp(out,"xyz\n")==0);
    std::string longLine(1500,'x');
    longLine += "\n";
    xdos_copy_terminal_tail(longLine.c_str(),out,16,2);
    assert(std::strlen(out)==15);
    assert(out[14]=='\n');
    std::puts("PASS: LVGL terminal viewport tests");
}
