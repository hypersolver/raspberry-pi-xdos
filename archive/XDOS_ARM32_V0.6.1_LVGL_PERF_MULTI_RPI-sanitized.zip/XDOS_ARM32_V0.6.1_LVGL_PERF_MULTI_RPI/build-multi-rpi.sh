#!/usr/bin/env bash
# Build each Raspberry Pi family with its own Circle RASPPI settings.
# Usage: ./build-multi-rpi.sh [1 2 3 4]
# XDOS_GUI=lvgl|legacy  XDOS_ENABLE_WIFI=auto|0|1  CIRCLE_HOME=... ./build-multi-rpi.sh 3
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
CIRCLE="${CIRCLE_HOME:-$HOME/xdos-build/circle}"
SOURCE="$ROOT/source/95-xdos-arm32-dualnet"
DEST="$CIRCLE/sample/96-xdos-lvgl-arduino"
GUI="${XDOS_GUI:-lvgl}"
TARGETS=("${@:-1 2 3 4}")
if [[ $# -eq 0 ]]; then TARGETS=(1 2 3 4); fi
[[ "$GUI" == lvgl || "$GUI" == legacy ]] || { echo "XDOS_GUI must be lvgl|legacy" >&2; exit 1; }
[[ -f "$CIRCLE/Rules.mk" ]] || { echo "Missing Circle source at: $CIRCLE" >&2; exit 1; }
for tool in arm-none-eabi-gcc arm-none-eabi-g++ arm-none-eabi-objcopy make git python3; do
  command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 1; }
done
mkdir -p "$ROOT/output" "$DEST"
cp -a "$SOURCE/." "$DEST/"
# Override only the target-specific Circle settings, preserve user Config2.mk.
TEMP_CONFIG="$(mktemp)"
ORIG_CONFIG="$CIRCLE/Config2.mk"
HAD_CONFIG=0
if [[ -e "$ORIG_CONFIG" ]]; then cp "$ORIG_CONFIG" "$TEMP_CONFIG"; HAD_CONFIG=1; fi
restore_config() {
  if [[ "$HAD_CONFIG" == 1 ]]; then cp "$TEMP_CONFIG" "$ORIG_CONFIG"; else rm -f "$ORIG_CONFIG"; fi
  rm -f "$TEMP_CONFIG"
}
trap restore_config EXIT
for board in "${TARGETS[@]}"; do
  case "$board" in
    1) outfile=kernel.img ;;
    2) outfile=kernel7.img ;;
    3) outfile=kernel8-32.img ;;
    4) outfile=kernel7l.img ;;
    *) echo "Invalid Pi: $board (expect 1 2 3 4)" >&2; exit 1 ;;
  esac
  wifi=0
  if [[ "$board" == 3 || "$board" == 4 ]]; then wifi=1; fi
  if [[ ${XDOS_ENABLE_WIFI:-auto} != auto ]]; then wifi=${XDOS_ENABLE_WIFI}; fi
  if [[ "$board" == 1 || "$board" == 2 ]] && [[ "$wifi" == 1 ]]; then
    echo "Onboard Wi-Fi not supported in Pi $board profile" >&2; exit 1
  fi
  if [[ "$HAD_CONFIG" == 1 ]]; then cp "$TEMP_CONFIG" "$ORIG_CONFIG"; else : > "$ORIG_CONFIG"; fi
  printf '\n# XDOS per-target override\nRASPPI = %s\nAARCH = 32\nPREFIX = arm-none-eabi-\n' "$board" >> "$ORIG_CONFIG"
  echo "===== Build Pi $board / $GUI / wifi=$wifi ====="
  (cd "$CIRCLE" && ./makeall clean && ./makeall)
  if [[ "$wifi" == 1 ]]; then
    git -C "$CIRCLE" submodule update --init addon/wlan/hostap
    make -C "$CIRCLE/addon/SDCard" clean
    make -C "$CIRCLE/addon/SDCard" -j"${JOBS:-2}"
    make -C "$CIRCLE/addon/fatfs" clean
    make -C "$CIRCLE/addon/fatfs" -j"${JOBS:-2}"
    (cd "$CIRCLE/addon/wlan" && ./makeall --nosample)
  fi
  if [[ "$GUI" == lvgl ]]; then
    git -C "$CIRCLE" submodule update --init addon/lvgl/lvgl
    make -C "$CIRCLE/addon/lvgl" clean
    make -C "$CIRCLE/addon/lvgl" -j"${JOBS:-2}"
  fi
  make -C "$DEST" clean
  make -C "$DEST" -j"${JOBS:-2}" XDOS_GUI="$GUI" XDOS_WIFI="$wifi" XDOS_LVGL_PERF="${XDOS_LVGL_PERF:-0}"
  test -s "$DEST/$outfile" || { echo "Missing build image $outfile" >&2; exit 1; }
  install -m 0644 "$DEST/$outfile" "$ROOT/output/$outfile"
  (cd "$ROOT/output" && sha256sum "$outfile" > "${outfile}.sha256")
done
echo "Finished. Images: $ROOT/output"
