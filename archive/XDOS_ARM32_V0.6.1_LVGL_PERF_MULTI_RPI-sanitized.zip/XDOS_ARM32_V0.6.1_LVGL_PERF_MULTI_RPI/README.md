# XDOS v0.6 – LVGL + Arduino + Raspberry Pi 1/2/3/4 (AArch32)

This is an **integration candidate**, based on the original XDOS V0.5.3 desktop-first archive. It has not yet passed full Circle linking or real-board tests. Read [README_ZH.md](README_ZH.md) for builds, target images, supported features, and limitations.

Example: `bash build-multi-rpi.sh 1 2 3 4` on an RPi4 Ubuntu cross-build host with Circle and arm-none-eabi.


**LVGL V0.6.1 optimization:** See [LVGL_PERFORMANCE.md](LVGL_PERFORMANCE.md). The V0.6.1 source is an integration candidate; no device benchmark has been run here.
