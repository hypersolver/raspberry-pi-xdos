> **V0.6.1 LVGL 性能優化補丁**：基於 V0.6 Multi-RPi 原始碼，不改動原 Circle BSP、Boot Splash 或 Arduino Core。新增 Label 版本號變更偵測、終端可見行裁切、Arduino 計數節流、時間基準 UI/網路刷新與可選 UART profiling。詳見 `LVGL_PERFORMANCE.md`。此版本尚未通過 ARM32 Circle 完整編譯與實機測試，勿直接覆寫已可正常開機的映像。

# XDOS ARM32 v0.6 Integration Candidate — LVGL + Arduino + Multi-RPi

**來源基準：**檔案庫 `XDOS_ARM32_ASM_V0.5_3_DESKTOP_FIRST_RPi3B.zip`，不是從零建立。

**狀態：原始碼整合候選版；已通過部分靜態驗證，尚未在 Circle 完整交叉連結或 Raspberry Pi 實機驗證。不要覆蓋已可開機的 V0.5.3 映像。**

## 支援矩陣（各版皆為 ARM32）

| 開發板 | Circle `RASPPI` | CPU/指令集 | 輸出 | 預設顯示 | 網路基準 |
|---|---:|---|---|---|---|
| Raspberry Pi 1 A/B/A+/B+/Zero | 1 | ARM1176 / ARMv6，**無 NEON** | `kernel.img` | 640×480 RGB565 | B/B+ 有線 Ethernet；A/A+/Zero 無內建 LAN |
| Raspberry Pi 2 B | 2 | Cortex-A7 / ARMv7（早期 2B） | `kernel7.img` | 640×480 RGB565 | 有線 Ethernet |
| Raspberry Pi 3 B/B+ | 3 | Cortex-A53 / AArch32 | `kernel8-32.img` | 800×600 RGB565 | Ethernet，Wi-Fi 路徑啟用 |
| Raspberry Pi 4 B | 4 | Cortex-A72 / AArch32 | `kernel7l.img` | 1024×768 RGB565 | Ethernet，Wi-Fi 路徑可選 |

Circle build targets 依其官方 `RASPPI` 配置。Pi 2 B v1.2 等可能使用不同 CPU，請以實際板型確認。這不是 Pi 5 專案。

## 已納入的程式模組

- `xdos_lvgl.cpp/.h`：以 Circle 官方 LVGL v9 Wrapper（`CLVGL`）顯示 XDOS Boot Log、網路狀態與 Arduino Loop 計數。使用 RGB565 partial draw buffers。
- `xdos_arduino/Arduino.h`：公開 `setup()`/`loop()`、`pinMode`、`digitalWrite/read`、`millis/micros`、`delay`、`yield`、基本 `Serial` API。
- `xdos_arduino/arduino_core.cpp`：透過 Circle GPIO、CTimer、CScheduler、UART 實作。
- `xdos_arduino/sketch.cpp`：**安全的預設 Sketch**（不主動操作 GPIO），由獨立的協作式 task 執行。
- `examples/blink_gpio.cpp`：實體 GPIO17 範例，需確認接線與電流限制後才替換。
- `xdos_gui.S`：Pi1 使用 ARMv6，其餘使用 ARMv7 指令集設定；保留既有 ASM GUI 的 legacy 回退模式。
- `build-multi-rpi.sh`：逐一重新建置 Circle 與 add-on，再輸出獨立的 ARM32 影像，建置設定結束後恢復原本 Circle `Config2.mk`。

**不是**完整 Arduino IDE、Arduino Core Library 相容集、動態 Arduino App Loader、原生 USB Serial Monitor、編譯/執行任意第三方 `.ino`。

## RPi4 Ubuntu 交叉編譯

需有 `~/xdos-build/circle`、`arm-none-eabi-gcc/g++`、`make`、`git`、Python3；使用能搭配 Circle LVGL v9 Wrapper 的 Circle 版本（避免舊版 LVGL v8/v9 混用）。確保 Circle 目前已有需要的原始碼與 add-on 子模組。

```bash
cd ~/xdos-build
unzip -o XDOS_ARM32_V0.6_LVGL_ARDUINO_MULTI_RPI.zip
cd XDOS_ARM32_V0.6.1_LVGL_PERF_MULTI_RPI
bash build-multi-rpi.sh 1 2 3 4
# 或者只編 Pi4
bash build-multi-rpi.sh 4
# 原 V0.5.3 自訂 GUI 回退，用 Pi3：
XDOS_GUI=legacy bash build-multi-rpi.sh 3
```

建置器會修改**開發主機**上的 Circle `Config2.mk` 並在完成/出錯後還原。不要同時在另一個 Terminal 編譯相同 Circle 目錄；每個板型共用一個 Circle Library 建置目錄，因此必須依序編譯。資料夾 `sample/96-xdos-lvgl-arduino` 會被更新，但不會覆蓋既有 `sample/95-...`。

Wi-Fi：Pi3/4 預設啟用，但取決於 Circle WLAN 支援、板型韌體及 FAT32 內容。要強制使用 Ethernet-only：

```bash
XDOS_ENABLE_WIFI=0 bash build-multi-rpi.sh 4
```

**若既有 Circle 對 `TCP Connect` Timeout 有客製 patch，請另行檢視：新腳本不會自動修改 Circle 的網路核心原始碼。**

## MicroSD 開機部署

將對應板型 `output/kernel*.img` 複製至 FAT32 開機分割區，並保留原本成功的 firmware、DTB、overlays、Wi-Fi 韌體與 `config.txt`。在現有 `config.txt` 確保：

```ini
[all]
arm_64bit=0
disable_splash=1
# 單選：Pi1 kernel.img、Pi2 kernel7.img、Pi3 kernel8-32.img、Pi4 kernel7l.img
kernel=kernel7l.img
```

請按實際板型改 `kernel`，並保留先前已驗證的 HDMI 設定。RPi4 所需 `start4.elf/fixup4.dat/DTB` 與 Pi1-3 啟動檔不同，不能把原 Pi3 SD 韌體假設直接完整適用 Pi4。原映像不覆寫；建議先用另一張 SD 測試。

## Arduino Sketch 導入（最小子集）

```bash
python3 tools/import-ino.py examples/blink_gpio.cpp
# 亦可把最小單檔 .ino 匯入，工具只加 Arduino.h 並檢查 setup()/loop()
# 再以 build-multi-rpi.sh 選擇板型重新編譯 XDOS 映像
```

**重要：** `Serial.begin(baud)` 目前不會重新配置 Circle 擁有的 UART；實際 baud 固定為 XDOS Kernel 的 115200。Arduino 腳位使用 BCM GPIO 編號，並非 Arduino UNO pin numbering 或 Raspberry Pi 實體排針編號。`analogRead`、`analogWrite`、`Wire`、`SPI`、`attachInterrupt`、`USB Serial` 和動態載入 `.ino` 尚未實作。未知函式應在編譯時報錯，不能靜默假裝可用。

Arduino Sketch 透過 Circle **協作式** Scheduler 運作；`delay()` 會讓出 CPU，但無限迴圈且不呼叫 `yield/delay` 的 Sketch 仍會卡死 LVGL/Network。Sketch 能操作 GPIO，**目前沒有第三方程式的記憶體/權限隔離**。

### 開機 / Display RAM

LVGL 使用 Circle Wrapper 的 RGB565 兩份 partial buffer（各約 1/10 畫面）；不配置 XDOS 原本的全畫面 Back Buffer。Boot Splash 繼續使用原 V0.5.3 的 direct drawing，**內含 `boot_splash_preview.png` 只是設計預覽，不會在板上載入**。

### LVGL 功能範圍

本版本 LVGL 介面目前是 Boot Log + Network Status + Arduino Loop 監看頁。原 V0.5.3 Desktop 的 Terminal/Notepad/Browser GUI **只保留在 `XDOS_GUI=legacy` 模式**；網路與 HTTP worker 仍可啟動，但其 LVGL 前端、文字輸入與 Browser UI 尚未完成遷移。請勿視為已完整移植舊桌面所有應用。

## 基本驗收清單

1. 針對 Pi1 / Pi2 / Pi3 / Pi4 獨立編譯，確認每一個 `kernel*.img` 都非空且位於 output/。
2. 檢查 UART 顯示 `LVGL` 與 `[ARDUINO]` 初始化訊息。
3. 接 USB 鍵盤/滑鼠，檢查 LVGL 指標移動，不得由 legacy MouseHandler 重複接管。
4. 網路線插入時，先看到 Desktop，後看到 DHCP IP；Pi3/4 再單獨測 Wi-Fi。
5. 無網路也能顯示 UI；確保 Sketch `delay()` 不阻塞 UI。
6. Pi1 僅使用 ARMv6 指令，不得包含 NEON；Pi4 不得使用 Pi3 的啟動映像。
7. A/B 對照 `XDOS_GUI=legacy`：測量 RAM、Frame time、啟動時間。

授權：Circle GPL-3.0、LVGL MIT、上游 Wi-Fi/WPA 與韌體依各自授權；若公開散布此整合映像，須另行完成授權義務與源碼/Notice 審核。
