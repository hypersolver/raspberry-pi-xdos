#!/usr/bin/env bash
# Host-side algorithm smoke test; DOES NOT validate an ARM Circle link.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
"${CXX:-g++}" -O2 -Wall -Wextra -Werror -std=c++17 \
  "$ROOT/tests/test_lvgl_tail.cpp" -o "$TMP/test-lvgl-tail"
"$TMP/test-lvgl-tail"
bash -n "$ROOT/build-multi-rpi.sh"
python3 -m py_compile "$ROOT/tools/import-ino.py"
echo "PASS: build script + import tool syntax"
