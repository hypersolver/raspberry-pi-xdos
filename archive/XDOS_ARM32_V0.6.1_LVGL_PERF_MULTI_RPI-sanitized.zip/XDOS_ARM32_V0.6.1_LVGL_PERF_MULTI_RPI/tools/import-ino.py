#!/usr/bin/env python3
"""Import a simple single-file Arduino sketch into XDOS's Sketch entrypoint.
This is NOT the full Arduino CLI preprocessor: no auto-generated prototypes,
multiple tabs, or binary Arduino package dependencies.
"""
from pathlib import Path
import argparse
p=argparse.ArgumentParser(description='Import one .ino into XDOS Arduino sketch.cpp')
p.add_argument('ino',type=Path)
p.add_argument('--dest',type=Path,default=Path(__file__).resolve().parents[1] / 'source/95-xdos-arm32-dualnet/xdos_arduino/sketch.cpp')
a=p.parse_args()
s=a.ino.read_text(encoding='utf-8-sig')
if not ('void setup(' in s and 'void loop(' in s):
    raise SystemExit('Sketch must define void setup() and void loop().')
if '#include "Arduino.h"' not in s:
    s='#include "Arduino.h"\n'+s
if a.dest.exists():
    backup=a.dest.with_suffix('.cpp.bak')
    backup.write_bytes(a.dest.read_bytes())
a.dest.write_text(s,encoding='utf-8')
print('Imported',a.ino,'->',a.dest)
