# XDOS LVGL V0.6.1 — 第一階段效能最佳化

以現有 V0.6（LVGL + Arduino + Multi-RPi）原始碼為基礎，保持 Circle BSP、16-bit RGB565、LVGL v9 與原 Legacy GUI 回退機制不變。

## 已完成的修改

1. `Desktop::TerminalRevision()/NetworkRevision()`：將畫面資料改用遞增版本號標記。LVGL 若看到版本未變，就不再計算整段文字 hash，也不呼叫 `lv_label_set_text()`。
2. `xdos_copy_terminal_tail()`：在 1 KiB 固定陣列中取最後可見的 12/17/25 行，減少 LVGL 長 Label 的 layout 與 invalidation 工作；不分配 Heap。
3. Arduino Loop 計數：由原先每次 UI poll 可能更新 Label，改為最多每 500 ms 更新一次；計數沒有改變則不更新。
4. `CKernel::Run()`：改用 Circle 1 MHz 計時器決定 UI poll（33 ms）及網路狀態 poll（250 ms），而非依據主迴圈次數；先 `ui_.Refresh()`，再 `CLVGL::Update()`。
5. USB 裝置掃描由每 5 ms 一次改為 Hotplug 即時或每 250 ms，鍵盤 LED 由每 5 ms 更新改為 100 ms；降低 GUI idle polling 工作。
6. LVGL 和 Legacy 渲染路徑不互搶滑鼠、Framebuffer；Boot Splash 不變。未修改 Circle 第三方函式庫。

## 不應被誤認為已完成

- 本版尚未經 Raspberry Pi 1/2/3/4 實機量測 FPS / CPU 使用率，也沒有在此環境完成 Circle ARM32 連結。
- 未修改官方 `CLVGL` 的 RGB565 雙 partial buffer（官方目前以畫面 1/10 x 2 配置）。這個配置在 RPi4 1024x768 約 307 KiB；縮小緩衝區可能降低 RAM 卻增加 Flush 次數，不宜在未量測前一概縮小。
- 此版沒有 GPU 合成，也未加入 Native App Hot Swap / Arduino INI 載入器。

## 比較方法

使用同一 SD 卡、同一解析度與相同韌體，A/B 比較 V0.6 與 V0.6.1：

- HDMI：畫面更新正常、字型不殘影、長 Boot Log 不超出 Terminal 區域。
- Input：USB 鍵盤/滑鼠可用、LVGL 指標移動正常。
- Network：延後 DHCP 不影響首屏，狀態不會過度刷新。
- Arduino：`delay()` 不阻塞 GUI，Loop count 約每 0.5 秒更新。
- CPU：測量主迴圈 sleep/WFI 比例及空閒時的 LVGL flush 次數；理論上不變時應趨近 0 次 UI invalidation。
- Pi1：ARMv6 不含 NEON，先試 640×480；Pi4 試 1024×768。

## 未來優化（需實機 Profiling 後選擇）

- Circle CLVGL buffer 5%、10%、20% 的 A/B 流量測試。
- Dirty Rectangle 與 Blit/DMA SetArea 的實際耗時比較，避免把較多 DMA 操作誤判成加速。
- GPU 加速需維持獨立實驗分支，不影響已穩定的軟體渲染與 LVGL GUI。

## 啟用 UART 效能統計

```bash
# RPi4 / 16-bit LVGL build; logs are printed to 115200 UART every 5 seconds
XDOS_LVGL_PERF=1 bash build-multi-rpi.sh 4
```

輸出例：`[LVGL PERF] Update avg=N us max=N us calls=N label_sets=N / 5s`。
`Update` 是 `CLVGL::Update()` 的呼叫耗時，**不是 GPU FPS**；`label_sets` 是 XDOS 額外使 LVGL Label invalidation 的次數。
這些數據應與同時測得的有效繪圖 FPS、VSync tearing、CPU idle time 比對，不可用 `label_sets` 直接推導 FPS。

將 `XDOS_LVGL_PERF=0`（預設）可關閉量測，避免對效能產生額外干擾。

## Host smoke test (Ubuntu/Windows WSL)

```bash
./tools/test-lvgl-host.sh
```

此測試驗證終端尾端裁切邏輯、build shell 語法與 Arduino 匯入工具語法；不代表 Circle 或 RPi 實機能正確執行。
