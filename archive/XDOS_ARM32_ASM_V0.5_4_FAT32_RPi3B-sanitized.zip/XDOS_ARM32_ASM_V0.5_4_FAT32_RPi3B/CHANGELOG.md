# Changelog

## V0.5.4-RC — FAT32 File I/O

- Preserve V0.5.3 desktop-first boot and Ethernet+Wi-Fi features.
- Mount onboard microSD FAT32 via `CEMMCDevice`, `f_mount()` after desktop first paint, even if wired LAN is up.
- Single `CStorageTask` handles application file operations; `FF_FS_REENTRANT=1` in upstream Circle FatFs.
- Files window lists `SD:/XDOS/` and provides Refresh.
- Terminal: `storage`, `ls`, `ls /`, `cat <name>`, `save`, `load`, `files`.
- Notepad: Save/Load buttons and Ctrl+S/Ctrl+O handling, `SD:/XDOS/NOTE.TXT`, 2 KiB limit.
- Rotate the previous note into `NOTE.BAK` using a flushed `NOTE.TMP` intermediate file.
- Deny traversal/absolute path in `cat`; no format/delete or boot-path write commands.
- Add splash FAT32 deferred status; bump splash progress steps to 13.
- Build in Circle `sample/96-xdos-arm32-fat32` to preserve previous sample directory.

*Compile/link on RPi4 and test on physical RPi3B/3B+ required before release.*
