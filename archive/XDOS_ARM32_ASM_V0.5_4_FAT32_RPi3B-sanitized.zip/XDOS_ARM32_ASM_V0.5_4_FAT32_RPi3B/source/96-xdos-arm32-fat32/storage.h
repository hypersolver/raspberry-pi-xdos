#ifndef XDOS_STORAGE_H
#define XDOS_STORAGE_H

#include <circle/sched/task.h>
class Desktop;

// This is the only task that performs XD OS application FatFs file I/O.
// SD:/XDOS is the application data directory, distinct from boot firmware.
class CStorageTask : public CTask
{
public:
    explicit CStorageTask(Desktop *desktop);
    void Run(void) override;
private:
    Desktop *desktop_;
};
#endif
