# XD OS ARM32 v0.5.4-RC — FAT32 storage integration

Cross-compile on RPi4 (Ubuntu 24.04 ARM64) for RPi 3B/3B+ ARM32 bare metal.

See [README_ZH.md](README_ZH.md) for exact Windows SCP, RPi4 build, SD card deployment and test steps.

## New components

- `source/96-xdos-arm32-fat32/storage.cpp` / `storage.h`: separate Circle cooperative file-I/O task using existing `addon/SDCard` + `addon/fatfs`.
- `source/96-xdos-arm32-fat32/kernel.cpp`: always mount FAT32 after desktop is visible, including when Ethernet is selected; create storage task before network probing.
- `source/96-xdos-arm32-fat32/desktop.cpp`: Files list/refresh; Notepad SAVE/LOAD; Terminal `storage`, `ls`, `ls /`, `cat`, `save`, `load`, `files`.
- `source/96-xdos-arm32-fat32/xdos_gui.S`: retained original ARM32 GUI assembly implementation.

Writes are confined to `SD:/XDOS/NOTE.TXT` with `.TMP`/`.BAK` rotation. No automatic boot writes and no formatting/deletion commands. Does not overwrite prior Circle sample 95 or tested kernel images.

## Build

```bash
cd ~/xdos-build
unzip -o XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B.zip
cd XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B
bash build-on-rpi4.sh
ls -l output/xdos32-v054-fat32.img
```

RC status: ARM32 assembly assembled and key source units syntax-checked using local stubs; GUI/FS logic tested on host mocks. Complete Circle link and RPi3B SD write tests remain outstanding.
