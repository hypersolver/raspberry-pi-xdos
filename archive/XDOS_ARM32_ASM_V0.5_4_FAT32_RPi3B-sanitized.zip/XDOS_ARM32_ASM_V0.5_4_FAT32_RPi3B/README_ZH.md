# XD OS ARM32 V0.5.4-RC — FAT32 Storage

**編譯主機**：Raspberry Pi 4 / Ubuntu 24.04.5 ARM64；**執行設備**：Raspberry Pi 3B 或 3B+ / ARM32 Bare-metal。

在原本 V0.5.3「桌面先顯示、網路進桌面後偵測、Ethernet + Wi-Fi」上，新增 MicroSD FAT32 讀寫與 Files/Notepad 功能。原有 ARM32 `xdos_gui.S`、USB、Browser、開機診斷保留。這不是完整純 ASM 系統：Circle 的 USB/SD/FatFs/網路仍採 C/C++，ASM 用於 GUI 底層。

## FAT32 行為

- 首次進入桌面後、在背景工作中初始化 MicroSD 與掛載 `SD:`；**有 Ethernet 連線時也照樣掛載**。
- 掛載完成後啟動獨立 `CStorageTask`，接收 GUI/Terminal 的檔案請求；不等待 Wi-Fi 或 DHCP 成功。
- 掛載只讀取 FAT32 中繼資料，不自動建立目錄或寫入檔案。
- Files 窗口列出 `SD:/XDOS/` 資料夾，按 `REFRESH` 可重查；尚不存在時顯示提示。
- Notepad 按 `SAVE`／`LOAD`，預設使用 `SD:/XDOS/NOTE.TXT`；也可使用 Ctrl+S／Ctrl+O（依 Circle 鍵盤映射而定）。
- SAVE 寫入 `NOTE.TMP`、`f_sync`，再將舊版輪替成 `NOTE.BAK`、新檔改名為 `NOTE.TXT`。FAT32 不支援真正的斷電原子交易；請避免寫入時斷電。
- Notepad 本版最多約 2 KiB 純文字；讀取超過上限的檔案會顯示錯誤，不會截斷後覆寫。Files 目錄清單最多約 4 KiB。
- Terminal 可透過 `cat NAME.TXT` 讀取 `SD:/XDOS/` 內單一檔案，最多約 4 KiB，不允許 `../` 或絕對路徑。
- 不提供刪除/格式化功能，也不修改 `bootcode.bin`、`config.txt`、`kernel*.img` 與 `firmware/`。

## Terminal 指令

```text
storage          顯示 FAT32 初始化狀態
ls               列出 SD:/XDOS/
ls /             列出 FAT32 根目錄（唯讀）
cat NOTE.TXT     顯示 SD:/XDOS/NOTE.TXT 的內容
save             儲存 Notepad 到 NOTE.TXT
load             從 NOTE.TXT 讀入 Notepad
files            開啟 Files 視窗
help             列出完整指令
```

進桌面後狀態從 `FAT32: INITIALIZING` → `FAT32: MOUNTING...` → `FAT32: READY`。網路繼續依原版本在進桌面後偵測。

## RPi 4 安裝編譯

1. Windows 先下載 `XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B.zip` 到 `Downloads`。
2. Windows PowerShell 傳送：

```powershell
scp "$env:USERPROFILE\Downloads\XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B.zip" davis@rpi4.local:/home/pi/xdos-build/
```

3. 連到 Raspberry Pi 4，執行：

```bash
cd ~/xdos-build
unzip -o XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B.zip
cd XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B
bash build-on-rpi4.sh
ls -lh output/xdos32-v054-fat32.img
sha256sum -c output/SHA256SUM.txt
```

腳本只建立/更新 Circle 的 `sample/96-xdos-arm32-fat32`，不覆蓋先前 `sample/95-xdos-arm32-dualnet`。但仍會沿用此前的**帶備份** TCP Timeout 共用修補；執行前建議保留 Circle 工作樹備份。

4. Windows PowerShell 取回映像：

```powershell
scp davis@rpi4.local:/home/pi/xdos-build/XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B/output/xdos32-v054-fat32.img "$env:USERPROFILE\Downloads\"
```

5. 將該 `.img` 複製到 RPi 3B/3B+ MicroSD FAT32 根目錄，保留原先 `firmware/` 和 `wpa_supplicant.conf`。更改 `config.txt`：

```ini
[all]
arm_64bit=0
kernel=xdos32-v054-fat32.img
```

既有 HDMI/UART/GPU 參數不用更動。**保留原本可以開機的 V0.5.3 `.img`，先用備用 MicroSD 測試 FAT32 寫入。**

## 實機驗收

1. 開機後進入空白桌面，沒有自動跳出 Terminal 或 Notepad；無需等待網路。
2. 等狀態顯示 `FAT32: READY`，開 Files 查看 FAT32 `SD:/XDOS/`。
3. 開 Notepad 輸入 `FAT32 TEST`，按 SAVE。File Explorer/Files 應看到 `NOTE.TXT`。
4. 將 SD 卡插回 Windows 時，應能找到 `XDOS/NOTE.TXT` 且內容符合輸入；第一次測試可先不拔卡，在 XD OS 直接按 LOAD 驗證。
5. 再按一次 SAVE，確認 `XDOS/NOTE.BAK` 存在且保留上一版內容。
6. Terminal 執行 `ls`、`cat NOTE.TXT`、`ls /`。最後確認 Ethernet/Wi-Fi 和 Browser 功能仍正常。

### 已完成的檢查與尚未驗證

- `xdos_gui.S` 已在本機用 Clang 的 ARMv7A/AArch32 目標組譯成功。
- `desktop.cpp`、`kernel.cpp`、`storage.cpp`、`boot_splash.cpp` 已通過模擬 Circle 介面下的語法檢查。
- 桌面檔案命令與 Notepad 請求已通過本機單元測試；FAT32 的儲存/讀取/列目錄/備份/路徑保護經主機端模擬測試通過。
- **尚未在 Raspberry Pi 4 的完整 Circle 原始碼中正式編譯/連結，也尚未在 Pi 3B/3B+ 上實際讀寫 MicroSD。** 因此版本標記為 RC。

## 其他限制

- FAT32 不是 journaling filesystem。任何寫入期間請不要斷電或直接拔卡。
- 本版寫入功能僅限 Notepad 的 `SD:/XDOS/NOTE.TXT`；一般檔案刪除、重新命名、二進位編輯與完整檔案管理器仍未加入。
- Circle FatFs 目前 `FF_FS_REENTRANT=1`，可保護多工作業中的 FatFs 存取；但仍應在實機檢查 SD/SDIO/Wi-Fi 同時使用時的穩定性。
- 有關 Circle、WLAN/WPA 與韌體等上游程式碼與授權，請遵循原專案授權條款。
