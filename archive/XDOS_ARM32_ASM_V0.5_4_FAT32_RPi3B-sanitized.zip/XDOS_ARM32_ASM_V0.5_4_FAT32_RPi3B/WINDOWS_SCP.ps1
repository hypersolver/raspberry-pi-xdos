# Run in Windows PowerShell after downloading XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B.zip
$zip = Join-Path $env:USERPROFILE 'Downloads\XDOS_ARM32_ASM_V0.5_4_FAT32_RPi3B.zip'
if (-not (Test-Path $zip)) { throw "File not found: $zip" }
scp $zip davis@rpi4.local:/home/pi/xdos-build/
Write-Host 'Now SSH to davis@rpi4.local and run the commands in README_ZH.md.'
