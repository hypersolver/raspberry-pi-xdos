param(
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^[A-Za-z]:$')]
    [string]$Drive,
    [ValidateSet('r32-d512','r64-d512','r96-d512','r64-d1024')]
    [string]$Variant='r64-d512'
)
$ErrorActionPreference='Stop'
$root="$Drive\"
$bench=Join-Path $root 'XDOS\BENCH'
if (-not (Test-Path $bench)){throw "No XDOS/BENCH directory: $bench"}
$runId=(Get-Date -Format 'yyyyMMdd-HHmmss')
$dst=Join-Path $env:USERPROFILE "Downloads\XDOS-RC2-Test\RESULTS\${Variant}_${runId}"
New-Item -ItemType Directory -Path $dst -Force | Out-Null
foreach($file in @('BENCH.CSV','P0DMA.CSV')){
    $source=Join-Path $bench $file
    if(Test-Path $source){Copy-Item -LiteralPath $source -Destination $dst}
    else {Write-Warning "Missing $source"}
}
@("variant=$Variant","collected=$runId","board=Pi3",'resolution=1024x768','depth=16','display=HDMI') | Set-Content (Join-Path $dst 'RUN_INFO.txt')
Write-Host "Collected results: $dst"
Write-Host 'Upload BENCH.CSV and P0DMA.CSV here for analysis.'
