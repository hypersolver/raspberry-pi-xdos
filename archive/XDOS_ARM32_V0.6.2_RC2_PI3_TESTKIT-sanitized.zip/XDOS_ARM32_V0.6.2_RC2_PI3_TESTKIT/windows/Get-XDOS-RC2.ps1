param(
    [ValidateSet('r32-d512','r64-d512','r96-d512','r64-d1024')]
    [string]$Variant='r64-d512',
    [string]$RemoteHost='rpi4.local',
    [string]$RemoteUser='davis'
)
$ErrorActionPreference='Stop'
$remoteRoot="/home/pi/xdos-build/XDOS_ARM32_V0.6.2_RC2_PI3_TESTKIT/output"
$localRoot=Join-Path $env:USERPROFILE 'Downloads\XDOS-RC2-Test'
$localVariant=Join-Path $localRoot $Variant
New-Item -ItemType Directory -Path $localVariant -Force | Out-Null
$name="xdos32-v062-rc2-${Variant}.img"
function Get-Remote([string]$path,[string]$dest) {
  $src="${RemoteUser}@${RemoteHost}:${path}"
  & scp $src $dest
  if($LASTEXITCODE -ne 0){throw "SCP failed: $src"}
}
Get-Remote "$remoteRoot/matrix/$Variant/$name" $localVariant
Get-Remote "$remoteRoot/matrix/$Variant/$name.sha256" $localVariant
Get-Remote "$remoteRoot/matrix/$Variant/BUILD_INFO.txt" $localVariant
# The two native module pairs are identical across kernel variants.
$appFolder=Join-Path $localRoot 'APPS'
New-Item -ItemType Directory -Path $appFolder -Force | Out-Null
foreach($file in @('LVGLDEMO.APP','LVGLDEMO.XAPP','LVGLBENCH.APP','LVGLBENCH.XAPP')) {
  Get-Remote "$remoteRoot/$file" $appFolder
}
$expected=(Get-Content (Join-Path $localVariant "$name.sha256") -Raw).Split(' ')[0].Trim().ToLowerInvariant()
$actual=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $localVariant $name)).Hash.ToLowerInvariant()
if($expected -ne $actual){throw "SHA256 mismatch for $name ($expected vs $actual)"}
Write-Host "Verified download: $localVariant\$name"
Write-Host "Next: .\Deploy-XDOS-RC2.ps1 -Drive E: -Variant $Variant (adjust drive letter)"
