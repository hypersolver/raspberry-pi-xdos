param(
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^[A-Za-z]:$')]
    [string]$Drive,
    [ValidateSet('r32-d512','r64-d512','r96-d512','r64-d1024')]
    [string]$Variant='r64-d512'
)
$ErrorActionPreference='Stop'
$root="$Drive\"
if (-not (Test-Path -LiteralPath (Join-Path $root 'config.txt'))) {throw "No config.txt on $Drive. Check SD card drive letter."}
if (-not (Test-Path -LiteralPath (Join-Path $root 'start.elf'))) {throw 'No start.elf on selected drive; refuse to write.'}
$name="xdos32-v062-rc2-${Variant}.img"
$downloads=Join-Path $env:USERPROFILE 'Downloads\XDOS-RC2-Test'
$src=Join-Path (Join-Path $downloads $Variant) $name
$apps=Join-Path $downloads 'APPS'
if (-not (Test-Path $src)){throw "Image not found: $src"}
$sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $src).Hash
$backup=Join-Path $downloads ('config-backup-'+(Get-Date -Format yyyyMMdd-HHmmss)+'.txt')
Copy-Item -LiteralPath (Join-Path $root 'config.txt') -Destination $backup
Copy-Item -LiteralPath $src -Destination (Join-Path $root $name) -Force
$dstApp=Join-Path $root 'XDOS\APPS'
New-Item -ItemType Directory -Path $dstApp -Force | Out-Null
foreach($file in @('LVGLDEMO.APP','LVGLDEMO.XAPP','LVGLBENCH.APP','LVGLBENCH.XAPP')) {
  $item=Join-Path $apps $file
  if (-not (Test-Path $item)){throw "Missing application: $item"}
  Copy-Item -LiteralPath $item -Destination $dstApp -Force
}
# Keep HDMI/Wi-Fi settings; only replace kernel and arm_64bit directives.
$cfg=Join-Path $root 'config.txt'
$lines=[System.IO.File]::ReadAllLines($cfg)
$kept=@($lines | Where-Object {$_ -notmatch '^\s*(kernel|arm_64bit)\s*='})
$kept += '[all]'
$kept += 'arm_64bit=0'
$kept += "kernel=$name"
[System.IO.File]::WriteAllLines($cfg,$kept,(New-Object System.Text.UTF8Encoding($false)))
$copied=(Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $root $name)).Hash
if($sha -ne $copied) {throw "SD copied image SHA256 mismatch for $name"}
Write-Host "SD image VERIFIED: $root$name"
Write-Host "Config backed up: $backup"
Write-Host 'Keep the old kernel images. Safely eject the MicroSD before boot.'
