# XD OS ARM32 v0.6.2-RC2 — Pi 3 P0 LVGL Test Kit

**A test/deployment supplement to the RC2 source candidate, not a new kernel release.**

- ARM32 kernel source and Circle P0 patch logic are **unchanged** from `XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI.zip`.
- Adds `build-test-matrix-on-rpi4.sh`: build parameterized 32/64/96-row kernels, preserve SHA-256 and build logs.
- Adds `windows/Get-XDOS-RC2.ps1`, `Deploy-XDOS-RC2.ps1`, `Collect-XDOS-RC2.ps1` for the user's `RPi4 Ubuntu -> Windows -> MicroSD -> RPi3B` path.
- Adds `tools/compare-matrix.py`: analyze last complete four-scene LVGL Benchmark sessions.
- All instructions in **`TEST_PLAN_ZH.md`**.

## Verified here

Host RGB565, P0 patch idempotence and LVGL mock-header syntax tests passed. Shell and Python syntax passed. Comparison script passed a synthetic two-run test. **No user Pi4 Circle full link or Pi3B DMA hardware test was performed here.**

Keep a known-good `.img` on the MicroSD for recovery. DMA results are experimental until hardware-validated.
