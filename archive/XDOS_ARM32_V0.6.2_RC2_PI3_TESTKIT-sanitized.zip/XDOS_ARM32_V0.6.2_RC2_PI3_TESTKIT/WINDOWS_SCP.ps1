# Windows PowerShell - retrieve V0.6.2-RC2 kernel and XAPP modules after Pi4 build.
$remote='davis@rpi4.local:/home/pi/xdos-build/XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI/output'
$dst=Join-Path $env:USERPROFILE 'Downloads\XDOS-RC2'
New-Item -ItemType Directory -Force -Path $dst | Out-Null
scp "${remote}/xdos32-v062-rc2-pi3.img" "$dst/"
scp "${remote}/LVGLBENCH.APP" "$dst/"
scp "${remote}/LVGLBENCH.XAPP" "$dst/"
scp "${remote}/LVGLDEMO.APP" "$dst/"
scp "${remote}/LVGLDEMO.XAPP" "$dst/"
Write-Host "Files copied to: $dst"
