# XD OS V0.6.2-RC2（Pi 3 專用）

使用說明請見 [README_P0_ZH.md](README_P0_ZH.md)。本版從 RC1 延伸，保留 Arduino Native、SDK/XAPP、FAT32、網路與 Benchmark，專注 5 項 P0 顯示優化。
