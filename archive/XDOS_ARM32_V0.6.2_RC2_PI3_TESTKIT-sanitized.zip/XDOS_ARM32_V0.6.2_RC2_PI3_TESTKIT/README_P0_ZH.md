# XD OS ARM32 v0.6.2-RC2 — LVGL 五項 P0 最佳化（Pi 3B/3B+）

## 改動與驗證狀態

| P0 | 修改 | 是否已實作於原始碼 | 實機驗證 |
|---|---|---|---|
| Dirty Area | LVGL 原生局部失效區域；小區域 (< 512px) CPU、其餘 DMA；Benchmark Dirty Pixels 計數 | 是，保留原生 LVGL partial invalidate | 待測 |
| DMA Async Flush | 回到 Circle `CBcmFrameBuffer::SetArea()`，使用完成 IRQ callback 才呼叫 `lv_display_flush_ready`；大型更新不再同步 CPU Copy | 是 | 待測 |
| Render Buffer | partial RGB565 雙緩衝預設 64 行，可 A/B 比較 32/64/96 行 | 是 | 待測 |
| DMA Busy Waiting | 修改 Circle 單 DMA channel 衝突時的旋轉等待，以 `CScheduler::MsSleep(1)`（或啟用中斷情境下 WFI）等待完成 | 是，僅 GUI Task Context 可用 | 待測 |
| LVGL Timer / Idle | 依 `lv_timer_handler()` 回傳值在 5..20ms 間調整、Circle Scheduler WFI；5 秒 UART CPU Idle 估算 | 是 | 待測 |

**此 RC2 僅針對 RPi 3B/3B+，不代表已支援 RPi1/2/4。**  RPi 4 Ubuntu ARM64 仍是編譯主機。

### 技術與安全注意

1. Circle 原生 `SetArea` 在 `SCREEN_DMA_BURST_LENGTH` 啟用時才會採用 DMA，建置前須確認未定義 `NO_SCREEN_DMA_BURST_LENGTH`（預設 Circle 為 burst=2）。若禁用 DMA，回呼為同步，計數就不能視為 DMA 時間。
2. 在 Circle DMA callback 完成之前，LVGL 不可覆寫來源 Draw Buffer；保留 LVGL 官方 `lv_display_flush_ready` 握手機制。
3. `CScheduler::MsSleep` 只能在正常 Task Context 使用，不得從 IRQ、FIQ 或關閉 IRQ 的區段呼叫。對於一般 XD OS LVGL 主工作可用；若上游 Circle 改變呼叫上下文需重新審查。
4. 若 DMA 修改引起停畫面、USB 延遲或 Wi-Fi 異常，換回已驗證的舊 Kernel；請勿在操作當中拔出 FAT32 SD 卡。
5. 本版沒有新的 DMA 驅動，使用的是 Circle 現有的 DMA2D 搬運能力；RGB565 仍是 LVGL 軟體渲染，DMA 只負責複製至顯示用記憶體。
6. 對極小面積 Dirty Region，CPU `memcpy` 可能更快；512 像素僅為初始分界，需由 Benchmark 驗證。
7. FPS 是 LVGL Render 完成事件，不等於 HDMI 掃描更新率；DMA 平均完成延遲另記錄於 `P0DMA.CSV`。Dirty pixels 是實際 Flush 的像素總量／完整幀像素量，部分重疊區域可能重複計數。
8. `WFI` 統計為 Idle 近似值，不是供電功率與晶片時脈測量。

## RPi 4 Ubuntu 24.04 ARM64 編譯

先在 Windows 下載此 ZIP，PowerShell 執行：

```powershell
scp "$env:USERPROFILE\Downloads\XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI.zip" davis@rpi4.local:/home/pi/xdos-build/
```

RPi4 SSH：

```bash
cd ~/xdos-build
unzip -o XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI.zip
cd XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI
bash tests/run-host-tests.sh
bash tests/run-lvgl-syntax-check.sh
bash build-on-rpi4.sh
ls -lh output/xdos32-v062-rc2-pi3.img
```

`build-on-rpi4.sh` 要求 Circle 使用 `RASPPI=3 / AARCH=32`，在全程備份修改前程式碼後更新 LVGL / Framebuffer / Scheduler。

需要重新試 Render Buffer 參數時，執行以下其中一個，再進行 benchmark：

```bash
XDOS_BUFFER_ROWS=32 bash build-on-rpi4.sh
XDOS_BUFFER_ROWS=64 bash build-on-rpi4.sh
XDOS_BUFFER_ROWS=96 bash build-on-rpi4.sh
```

或測試 DMA 閾值（64..4096 Pixel）：

```bash
XDOS_DMA_MIN_PIXELS=1024 bash build-on-rpi4.sh
```

**注意**：多次編譯會覆蓋 RC2 的輸出檔，建議各次更名為 `xdos32-rc2-row32.img`、`xdos32-rc2-row64.img` 等，並記錄對應 Buffer 設定；請勿直接比較不同解析度／色深的 FPS。

## Windows 取回與 SD 卡部署

Windows PowerShell（可直接使用套件中的 `WINDOWS_SCP.ps1`）：

```powershell
$src="davis@rpi4.local:/home/pi/xdos-build/XDOS_ARM32_V0.6.2_RC2_PI3_P0_GUI/output"
scp "${src}/xdos32-v062-rc2-pi3.img" "$env:USERPROFILE/Downloads/"
scp "${src}/LVGLBENCH.APP" "$env:USERPROFILE/Downloads/"
scp "${src}/LVGLBENCH.XAPP" "$env:USERPROFILE/Downloads/"
```

將 `.img` 放在 MicroSD FAT32 根目錄，並把 `.APP`／`.XAPP` 放進 `XDOS/APPS/`；在 config.txt 中設定：

```ini
[all]
arm_64bit=0
kernel=xdos32-v062-rc2-pi3.img
hdmi_force_hotplug=1
hdmi_group=2
hdmi_mode=16
enable_uart=1
```

請保留先前可成功開機的 RC1／RC2 舊測試映像，以便回復。

## Benchmark

4 場景與 RC1 **完全相同**：TEXT_24、MOVE_36、ALPHA_24、FULL_REDRAW；每場 2 秒暖機 + 10 秒量測，測試總計約 48 秒。

原版 `SD:/XDOS/BENCH/BENCH.CSV` 欄位與 RC1 相同，可直接使用 `tools/compare-benchmark.py` 比較 FPS／Render／Flush callback。新增 `SD:/XDOS/BENCH/P0DMA.CSV`，包含各場景 DMA 完成平均時間、CPU Flush 次數、Dirty Pixels、DMA 閾值與 Buffer Rows。

測試環境需固定 1024×768@60Hz、16-bit RGB565、相同 USB／Wi-Fi 狀態。優先測 RC1（CPU flush）及 RC2（DMA hybrid），再測 RC2 32/64/96 行，使用多次取樣判定。

## 當機與故障判讀

若 RC2 開機停在 Splash，先檢查 Kernel 檔名。若只有 LVGL 不更新，先用 UART 檢查是否卡在 DMA Complete IRQ／`lv_display_flush_ready`。若移動滑鼠卡住，確認 `SCREEN_DMA_BURST_LENGTH` 是否真正啟用並檢查 Circle framebuffer DMA Busy guard。若測試後 CSV 失敗，保留畫面摘要與 UART 日誌。

**驗證宣告：本 ZIP 是原始碼整合候選版；完成了本機 Host 測試與 Patch 文字變更測試，但未在用戶 RPi 4 完整交叉編譯與 RPi 3B 實機驗證。**
