#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
g++ -std=c++17 -O2 -Wall -Wextra -Werror -o /tmp/xdos-v062-bench-flush-test "$root/tests/test_lvgl_flush.cpp"
/tmp/xdos-v062-bench-flush-test

python3 "$root/tests/test_circle_p0_patch.py"
