# XD OS V0.6.2 RC2 — Pi3 LVGL P0 performance

Base: V0.6.2 RC1 Benchmark (V0.6.1 plus 0.5.5 RC3). No change to the 4 benchmark workloads or ABI v1.

- Uses Circle asynchronous DMA2D flush completion for non-tiny RGB565 dirty rectangles.
- Retains fast CPU path for dirty areas below 512 pixels, adjustable.
- Configurable LVGL partial draw buffers: 32 / 64 / 96 rows (default 64).
- Replaces Circle `m_nDMAInUse` spin with task scheduler short sleep / WFI in single-core task context.
- Dynamic LVGL timer interval 5..20ms, with existing Scheduler WFI when all tasks are sleeping.
- Adds separate P0DMA.CSV for DMA completion time / dirty pixels; preserves BENCH.CSV RC1 schema.
- Existing XAPP SDK, Arduino Native, FAT32, Ethernet/Wi-Fi, Browser not deliberately modified.

Build and Pi3 target hardware tests not yet completed. Keep previous working image for rollback.
