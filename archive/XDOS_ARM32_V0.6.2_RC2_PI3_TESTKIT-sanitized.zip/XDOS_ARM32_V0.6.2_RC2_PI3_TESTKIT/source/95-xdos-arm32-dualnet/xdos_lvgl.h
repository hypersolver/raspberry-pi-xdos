#ifndef XDOS_LVGL_UI_H
#define XDOS_LVGL_UI_H
#include <lvgl/lvgl.h>
#include "xdos_benchmark.h"
class Desktop;
class CSerialDevice;
class XDOSLVGL {
public:
    XDOSLVGL();
    void Initialize(Desktop *desktop, CSerialDevice *serial);
    void Refresh(unsigned nowUs);
    void Tick(unsigned nowUs);
    void OnKey(char ch);
    bool StartBenchmark();
    bool StartWidgetsDemo();
    unsigned TextUpdateCount() const { return textUpdateCount_; }
private:
    static void BenchButton(lv_event_t *event);
    static void DemoButton(lv_event_t *event);
    static void DemoBack(lv_event_t *event);
    Desktop *desktop_;
    CSerialDevice *serial_;
    XDOSBenchmark benchmark_;
    lv_obj_t *homeScreen_, *demoScreen_, *title_, *status_, *term_, *sketch_;
    unsigned lastStatusRevision_,lastTerminalRevision_,lastLoops_,lastLoopSampleUs_;
    unsigned consoleLines_,textUpdateCount_;
    char terminalView_[1024];
};
#endif
