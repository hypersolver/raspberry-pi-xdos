#include "xdos_lvgl.h"
#include "xdos_lvgl_tail.h"
#include "desktop.h"
#include "xdos_arduino/xdos_arduino_runtime.h"
#include <circle/serial.h>
#include <lvgl/lvgl/demos/lv_demos.h>
#include <stdio.h>

namespace { static const unsigned LOOP_SAMPLE_US=500000U; }
XDOSLVGL::XDOSLVGL()
: desktop_(0),serial_(0),homeScreen_(0),demoScreen_(0),title_(0),status_(0),term_(0),sketch_(0),
  lastStatusRevision_(~0U),lastTerminalRevision_(~0U),lastLoops_(~0U),
  lastLoopSampleUs_(0),consoleLines_(16),textUpdateCount_(0)
{ terminalView_[0]=0; }

void XDOSLVGL::BenchButton(lv_event_t *event)
{
    if(lv_event_get_code(event)!=LV_EVENT_CLICKED) return;
    XDOSLVGL *ui=(XDOSLVGL *)lv_event_get_user_data(event);
    if(ui && ui->desktop_) ui->desktop_->RequestBenchmarkLaunch();
}
void XDOSLVGL::DemoButton(lv_event_t *event)
{
    if(lv_event_get_code(event)!=LV_EVENT_CLICKED) return;
    XDOSLVGL *ui=(XDOSLVGL *)lv_event_get_user_data(event);
    if(ui) ui->StartWidgetsDemo();
}
void XDOSLVGL::DemoBack(lv_event_t *event)
{
    if(lv_event_get_code(event)!=LV_EVENT_CLICKED) return;
    XDOSLVGL *ui=(XDOSLVGL *)lv_event_get_user_data(event);
    if(!ui || !ui->homeScreen_ || !ui->demoScreen_) return;
    lv_screen_load(ui->homeScreen_);
    lv_obj_delete_async(ui->demoScreen_);
    ui->demoScreen_=0;
}
static lv_obj_t *MakeButton(lv_obj_t *parent,const char *label,
                             lv_event_cb_t event,void *owner)
{
    lv_obj_t *button=lv_button_create(parent);
    lv_obj_set_height(button,37);
    lv_obj_add_event_cb(button,event,LV_EVENT_CLICKED,owner);
    lv_obj_t *text=lv_label_create(button);
    lv_label_set_text(text,label);
    lv_obj_center(text);
    return button;
}
void XDOSLVGL::Initialize(Desktop *desktop,CSerialDevice *serial)
{
    desktop_=desktop;serial_=serial;
    homeScreen_=lv_screen_active();
    lv_obj_set_style_bg_color(homeScreen_,lv_color_hex(0x101D2D),0);
    lv_obj_set_style_text_color(homeScreen_,lv_color_hex(0xD5F1DC),0);
    lv_obj_t *column=lv_obj_create(homeScreen_);
    lv_obj_set_size(column,lv_pct(100),lv_pct(100)); // RC3: full screen, no 96%x94% inset
    lv_obj_set_pos(column,0,0);
    lv_obj_set_style_pad_all(column,10,0);
    lv_obj_set_style_pad_row(column,5,0);
    lv_obj_set_flex_flow(column,LV_FLEX_FLOW_COLUMN);
    lv_obj_set_scrollbar_mode(column,LV_SCROLLBAR_MODE_OFF);
    lv_obj_set_style_bg_color(column,lv_color_hex(0x15283B),0);
    lv_obj_set_style_border_width(column,0,0);
    title_=lv_label_create(column);
    lv_label_set_text(title_,"XD OS 0.6.2-RC2  /  RPi 3 / LVGL 9 / Native SDK");
    lv_obj_set_style_text_color(title_,lv_color_hex(0x72E4AC),0);
    lv_obj_t *buttons=lv_obj_create(column);
    lv_obj_set_width(buttons,lv_pct(100));
    lv_obj_set_height(buttons,58);
    lv_obj_set_flex_flow(buttons,LV_FLEX_FLOW_ROW);
    lv_obj_set_style_pad_all(buttons,6,0);
    lv_obj_set_style_border_width(buttons,0,0);
    lv_obj_set_style_bg_color(buttons,lv_color_hex(0x20394D),0);
    MakeButton(buttons,"LVGL BENCHMARK APP",BenchButton,this);
    MakeButton(buttons,"LVGL Widgets Demo",DemoButton,this);
    status_=lv_label_create(column);
    lv_obj_set_width(status_,lv_pct(100));
    lv_label_set_text(status_,"NET: AFTER DESKTOP");
    sketch_=lv_label_create(column);
    lv_label_set_text(sketch_,"Arduino Native: starting");
    term_=lv_label_create(column);
    lv_obj_set_width(term_,lv_pct(100));
    lv_label_set_long_mode(term_,LV_LABEL_LONG_WRAP);
    lv_display_t *disp=lv_display_get_default();
    const unsigned h=disp?(unsigned)lv_display_get_vertical_resolution(disp):768U;
    consoleLines_=h>700U?25U:h>550U?17U:12U;
    lv_label_set_text(term_,"Terminal ready");
    Refresh(0);
}

bool XDOSLVGL::StartBenchmark()
{
    if(!homeScreen_ || benchmark_.Running()) return false;
    return benchmark_.Start(homeScreen_,desktop_,serial_);
}
bool XDOSLVGL::StartWidgetsDemo()
{
    if(!homeScreen_ || benchmark_.Running()) return false;
    if(demoScreen_) return true;
    demoScreen_=lv_obj_create(NULL);
    lv_obj_set_style_pad_all(demoScreen_,0,0);
    lv_obj_set_style_border_width(demoScreen_,0,0);
    lv_screen_load(demoScreen_);
    lv_demo_widgets();
    lv_obj_t *tab=lv_obj_get_child(demoScreen_,0);
    if(tab) {lv_obj_set_size(tab,lv_pct(100),lv_pct(100));lv_obj_set_pos(tab,0,0);}
    lv_obj_t *back=MakeButton(demoScreen_,"BACK XD OS",DemoBack,this);
    lv_obj_set_size(back,116,37);
    lv_obj_align(back,LV_ALIGN_TOP_RIGHT,-8,5);
    lv_obj_move_foreground(back);
    return true;
}
void XDOSLVGL::Tick(unsigned nowUs) {benchmark_.Tick(nowUs);}
void XDOSLVGL::OnKey(char ch) {(void)ch;}
void XDOSLVGL::Refresh(unsigned nowUs)
{
    if(!desktop_ || !term_ || benchmark_.Running()) return;
    unsigned revision=desktop_->NetworkRevision();
    if(revision!=lastStatusRevision_) {
        lv_label_set_text(status_,desktop_->NetworkStatus());
        ++textUpdateCount_; lastStatusRevision_=revision;
    }
    revision=desktop_->TerminalRevision();
    if(revision!=lastTerminalRevision_) {
        xdos_copy_terminal_tail(desktop_->TerminalText(),terminalView_,sizeof terminalView_,consoleLines_);
        lv_label_set_text(term_,terminalView_);
        ++textUpdateCount_;lastTerminalRevision_=revision;
    }
    if(lastLoops_==~0U || (unsigned)(nowUs-lastLoopSampleUs_)>=LOOP_SAMPLE_US) {
        const unsigned count=xdos_arduino_loop_count();
        if(count!=lastLoops_) {
            char line[80];
            snprintf(line,sizeof line,"Arduino Native  |  loop count: %u",count);
            lv_label_set_text(sketch_,line);
            ++textUpdateCount_;lastLoops_=count;
        }
        lastLoopSampleUs_=nowUs;
    }
}
